#!/bin/bash

# # Move to the parent directory
# cd ..

# # Check if Redis is running using tasklist (Windows alternative to pgrep)
# if ! tasklist | grep -q "redis-server.exe"; then
#     echo "Starting Redis server..."
#     cd ./Redis-x64-3.0.504
#     ./redis-server.exe &
#     cd ../CLineAutomation
# else
#     echo "Redis server is already running."
# fi

# Activate the virtual environment
echo "Activating virtual environment..."
source ../cline/Scripts/activate

# # Start Celery Beat in the background
# echo "Starting Celery Beat..."
# celery -A CLineAutomation beat --loglevel=info &

# # Start Celery Worker in the background
# echo "Starting Celery Worker..."
# celery -A CLineAutomation worker --loglevel=info &

# Start Django Server
echo "Starting Django development server on port 5566..."
python -u manage.py runserver 0.0.0.0:5566
