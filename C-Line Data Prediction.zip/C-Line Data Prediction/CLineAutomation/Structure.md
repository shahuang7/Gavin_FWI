# Project Overview
## This websites provides dashboards for monitoring and visualizing C-Line Automation machine (Powerfan, Dimm1, Dimm2, Dimm3, AOI) data and key metrics(Yield/Pressure/Error)
## This website is designed for ME and manager of C-Line Automation machines
## Key features include 
# Project Structure

bash start.sh


CLineAutomation/
- manage.py                    # Django management script
- CLineAutomation/             # Main project settings module
    - __init__.py              # Marks the folder as a Python package
    - asgi.py                  # ASGI configuration
    - settings.py              # Django project settings
    - urls.py                  # Root URL configuration
    - wsgi.py                  # WSGI configuration
- dashboard/                   # Main app for data management and dashboard
    - __init__.py              # Marks the folder as a Python package
    - admin.py                 # Admin interface configuration
    - apps.py                  # App configuration
    - models.py                # Data models (e.g., Line, Machine, YieldData)
    - views.py                 # Views to handle dashboard rendering and API responses
    - urls.py                  # URL routing for the dashboard app
    - migrations/              # Database migrations
        - __init__.py          # Marks migrations as a package
        - ...                  # Auto-generated migration files
    - templates/               # HTML templates for the dashboard
        - dashboard/
            - homepage.html    # Dashboard homepage template
            - ...              # Additional templates
    - static/                  # Static files (CSS, JS, images)
        - css/
        - js/
        - img/
    - utils/                   # Utility functions for database and updates
        - __init__.py          # Marks the folder as a Python package
        - db_utils.py          # Database connection and query functions
        - update_utils.py      # Functions for hourly/daily updates
    - tasks/                   # Task files for periodic operations
        - __init__.py          # Marks the folder as a Python package
        - real_time.py         # Fetch real-time data from the remote database
        - historical_update.py # Handle hourly/daily updates to Django's DB
    - management/commands/     # Custom management commands
        - __init__.py          # Marks the folder as a Python package
        - load_historical_data.py # Script to load historical data into the database
- .env                         # Environment variables for sensitive configuration
- requirements.txt             # Python dependencies
