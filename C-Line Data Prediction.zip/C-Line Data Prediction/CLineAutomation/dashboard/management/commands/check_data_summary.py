from django.core.management.base import BaseCommand
from dashboard.models import Line, Machine, YieldData, PressureData, ErrorData

class Command(BaseCommand):
    help = "Check total row count and last 5 rows for each line-machine combination in YieldData, PressureData, or ErrorData."

    def add_arguments(self, parser):
        parser.add_argument(
            '--type',
            type=str,
            choices=['yield', 'pressure', 'error'],
            required=True,
            help="Specify the type of data to check: 'yield', 'pressure', or 'error'."
        )

    def handle(self, *args, **options):
        data_type = options['type']
        if data_type == 'yield':
            self.check_data_summary(YieldData, "YieldData")
        elif data_type == 'pressure':
            self.check_data_summary(PressureData, "PressureData")
        elif data_type == 'error':
            self.check_data_summary(ErrorData, "ErrorData")

    def check_data_summary(self, model, model_name):
        # Total rows count
        total_rows = model.objects.count()
        self.stdout.write(f"Total rows in {model_name}: {total_rows}")

        # Determine if the model uses `start_date` instead of `date`
        date_field = 'start_date' if 'start_date' in [field.name for field in model._meta.fields] else 'date'

        # Last 5 rows for each line-machine combination
        combinations = model.objects.values('line', 'machine').distinct()
        for combination in combinations:
            line_id = combination.get('line')
            machine_id = combination.get('machine')

            # Fetch the line and machine names
            line_name = Line.objects.get(id=line_id).name if line_id else "Unknown Line"
            machine_name = Machine.objects.get(id=machine_id).name if machine_id else "Unknown Machine"
            
            row_count = model.objects.filter(line=line_id, machine=machine_id).count()
            self.stdout.write(f"Line: {line_name}, Machine: {machine_name} - Total rows: {row_count}")

            # Fetch last 5 rows for this line-machine combination
            last_rows = model.objects.filter(line=line_id, machine=machine_id).order_by(f'-{date_field}')[:5]

            self.stdout.write(f"\nLast 5 rows for Line: {line_name}, Machine: {machine_name}")
            for row in last_rows:
                # Exclude 'id', 'machine', and 'line' fields from the displayed data
                row_data = {
                    field.name: getattr(row, field.name)
                    for field in model._meta.fields
                    if field.name not in ['id', 'machine', 'line']
                }

                # Print the row
                self.stdout.write(str(row_data))

