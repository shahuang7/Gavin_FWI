import os
import csv
from django.core.management.base import BaseCommand
from dashboard.models import Line, Machine, YieldData, PressureData, ErrorData
import chardet
from datetime import datetime

def detect_encoding(file_path):
    """
    Detect the encoding of a file using chardet.
    """
    with open(file_path, 'rb') as file:
        result = chardet.detect(file.read())
        return result['encoding']
    
class Command(BaseCommand):
    help = "Load historical YieldData or PressureData from CSV files into the database."

    def add_arguments(self, parser):
        parser.add_argument(
            '--type',
            type=str,
            choices=['yield', 'pressure', 'error'],
            required=True,
            help="Specify the type of data to load: 'yield' or 'pressure' or 'error'."
        )

    def handle(self, *args, **kwargs):
        data_type = kwargs['type']
        data_path = "data/"  # Root folder containing C1-C6 directories
        lines = ['C2', 'C3', 'C4']
        machines = ['aoi', 'dimm1', 'dimm2', 'dimm3', 'powerfan']

        for line_name in lines:
            line_path = os.path.join(data_path, line_name)
            if not os.path.exists(line_path):
                self.stdout.write(f"Line folder {line_name} not found, skipping...")
                continue

            # Get or create the Line instance
            line, _ = Line.objects.get_or_create(name=line_name)

            for machine_name in machines:
                machine_path = os.path.join(line_path, machine_name)
                if not os.path.exists(machine_path):
                    self.stdout.write(f"Machine folder {machine_name} not found in {line_name}, skipping...")
                    continue

                # Get or create the Machine instance
                machine, _ = Machine.objects.get_or_create(name=machine_name, line=line)

                # Process files based on the type
                if data_type == 'yield':
                    self.process_yield_files(machine_path, machine, line)
                elif data_type == 'pressure':
                    self.process_pressure_files(machine_path, machine, line)
                elif data_type == 'error':
                    self.process_error_files(machine_path, machine, line)

    def process_yield_files(self, machine_path, machine, line):
        for file_name in os.listdir(machine_path):
            if file_name.startswith("yield_data") and file_name.endswith(".csv"):
                file_path = os.path.join(machine_path, file_name)
                self.stdout.write(f"Processing yield file: {file_path}")
                self.process_single_yield_csv(file_path, machine, line)

    def process_pressure_files(self, machine_path, machine, line):
        for file_name in os.listdir(machine_path):
            if file_name.startswith("pressure_data") and file_name.endswith(".csv"):
                file_path = os.path.join(machine_path, file_name)
                self.stdout.write(f"Processing pressure file: {file_path}")
                self.process_single_pressure_csv(file_path, machine, line)

    def process_error_files(self, machine_path, machine, line):
        for file_name in os.listdir(machine_path):
            if file_name.startswith("error_data") and file_name.endswith(".csv"):
                file_path = os.path.join(machine_path, file_name)
                self.stdout.write(f"Processing error file: {file_path}")
                self.process_single_error_csv(file_path, machine, line)

    def process_single_yield_csv(self, file_path, machine, line):
        try:
            with open(file_path, 'r') as file:
                reader = csv.DictReader(file)
                all_yield_data = []
                for row in reader:
                    try:
                        date = datetime.strptime(row['Date'], "%Y-%m-%d").date()
                        time_id = int(row['TimeID'])
                        run_time = int(row['RunTime'])
                        standby_time = int(row['StandByTime'])
                        error_time = int(row['ErrorTime'])
                        stop_time = int(row['StopTime'])
                        yield_value = int(row['Yield'])

                        all_yield_data.append(
                            YieldData(
                                machine=machine,
                                line=line,
                                date=date,
                                time_id=time_id,
                                run_time=run_time,
                                standby_time=standby_time,
                                error_time=error_time,
                                stop_time=stop_time,
                                yield_value=yield_value
                            )
                        )
                    except (ValueError, KeyError) as e:
                        self.stdout.write(f"Skipping invalid row: {row} | Error: {e}")

                if all_yield_data:
                    self.insert_yield_records(all_yield_data, file_path)
        except Exception as e:
            self.stdout.write(f"Error processing yield file {file_path}: {e}")

    def process_single_pressure_csv(self, file_path, machine, line):
        try:
            with open(file_path, 'r') as file:
                reader = csv.DictReader(file)
                all_pressure_data = []
                for row in reader:
                    try:
                        date = datetime.strptime(row['Date'], "%Y-%m-%d").date()
                        time = datetime.strptime(row['Time'], "%H:%M:%S").time()
                        product_sn = row.get('ProductSN', None)
                        type_ = row['Type']
                        num = int(row['Num'])
                        max_value = float(row['MaxValue'])

                        all_pressure_data.append(
                            PressureData(
                                machine=machine,
                                line=line,
                                date=date,
                                time=time,
                                product_sn=product_sn,
                                type=type_,
                                num=num,
                                max_value=max_value
                            )
                        )
                    except (ValueError, KeyError) as e:
                        self.stdout.write(f"Skipping invalid row: {row} | Error: {e}")

                if all_pressure_data:
                    self.insert_pressure_records(all_pressure_data, file_path)
        except Exception as e:
            self.stdout.write(f"Error processing pressure file {file_path}: {e}")
    
    def process_single_error_csv(self, file_path, machine, line):
        """
        Load and insert data from a single ErrorData CSV file with encoding detection.
        """
        try:
            # Detect the file's encoding
            encoding = detect_encoding(file_path)
            self.stdout.write(f"Detected encoding for {file_path}: {encoding}")

            with open(file_path, 'r', encoding=encoding) as file:
                reader = csv.DictReader(file)
                all_error_data = []
                for row in reader:
                    try:
                        start_date = datetime.strptime(row['StartDate'], "%Y-%m-%d").date()
                        start_time = datetime.strptime(row['StartTime'], "%H:%M:%S").time()
                        end_date = datetime.strptime(row['EndDate'], "%Y-%m-%d").date()
                        end_time = datetime.strptime(row['EndTime'], "%H:%M:%S").time()
                        desc_id = row['DescID']
                        error_code = row['Error_Code']
                        error_chinese_def = row.get('Error_Chinese_Def', '')
                        error_english_def = row.get('Error_English_Def', '')
                        error_def = row.get('Error_Def', '')

                        all_error_data.append(
                            ErrorData(
                                machine=machine,
                                line=line,
                                start_date=start_date,
                                start_time=start_time,
                                end_date=end_date,
                                end_time=end_time,
                                desc_id=desc_id,
                                error_code=error_code,
                                error_chinese_def=error_chinese_def,
                                error_english_def=error_english_def,
                                error_def=error_def
                            )
                        )
                    except (ValueError, KeyError) as e:
                        self.stdout.write(f"Skipping invalid row: {row} | Error: {e}")

                if all_error_data:
                    self.insert_error_records(all_error_data, file_path)
        except Exception as e:
            self.stdout.write(f"Error processing error file {file_path}: {e}")

    def insert_yield_records(self, all_yield_data, file_path):
        self.stdout.write(f"Preparing to insert {len(all_yield_data)} yield records from {file_path}...")
        try:
            YieldData.objects.bulk_create(all_yield_data, batch_size=1000)
            self.stdout.write(f"Successfully inserted {len(all_yield_data)} yield records.")
        except Exception as e:
            self.stdout.write(f"Error during bulk insert: {e}")

    def insert_pressure_records(self, all_pressure_data, file_path):
        self.stdout.write(f"Preparing to insert {len(all_pressure_data)} pressure records from {file_path}...")
        try:
            PressureData.objects.bulk_create(all_pressure_data, batch_size=1000)
            self.stdout.write(f"Successfully inserted {len(all_pressure_data)} pressure records.")
        except Exception as e:
            self.stdout.write(f"Error during bulk insert: {e}")

    def insert_error_records(self, all_error_data, file_path):
        self.stdout.write(f"Preparing to insert {len(all_error_data)} error records from {file_path}...")
        try:
            ErrorData.objects.bulk_create(all_error_data, batch_size=1000)
            self.stdout.write(f"Successfully inserted {len(all_error_data)} error records.")
        except Exception as e:
            self.stdout.write(f"Error during bulk insert: {e}")

