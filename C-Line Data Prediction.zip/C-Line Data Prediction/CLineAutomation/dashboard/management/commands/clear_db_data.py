from django.core.management.base import BaseCommand
from dashboard.models import Line, Machine, YieldData, ErrorData, PressureData
from django.db.models import Q

'''
Example arguments:
1. Clean all YieldData records for C3-dimm1 from 2024-12-01 onwards:
    python manage.py clear_db_data --type yield --line C3 --machine dimm1 --date 2024-12-01
2. Clean all ErrorData records for C2 line from 2024-11-25 onwards:
    python manage.py clear_db_data --type error --line C2 --date 2024-11-25
3. Clean all PressureData for all lines and machines from 2024-10-01 onwards:
    python manage.py clear_db_data --type pressure --date 2024-10-01
4. Clean all YieldData for all lines and machines:
    python manage.py clear_db_data --type yield
'''

class Command(BaseCommand):
    help = "Clear specified data from the local database for given models and filters."

    def add_arguments(self, parser):
        parser.add_argument(
            '--type',
            type=str,
            choices=['yield', 'error', 'pressure'],
            required=True,
            help="Specify the type of data to clean: 'yield', 'error', or 'pressure'."
        )
        parser.add_argument(
            '--line',
            type=str,
            help="Specify the line name to filter. Leave blank to apply to all lines."
        )
        parser.add_argument(
            '--machine',
            type=str,
            help="Specify the machine name to filter. Leave blank to apply to all machines."
        )
        parser.add_argument(
            '--date',
            type=str,
            help="Specify the date (YYYY-MM-DD) to clear data from (include and after)."
        )

    def handle(self, *args, **options):
        data_type = options['type']
        line_name = options['line']
        machine_name = options['machine']
        date = options['date']

        # Map model and field names
        model_mapping = {
            'yield': (YieldData, 'date'),
            'error': (ErrorData, 'start_date'),
            'pressure': (PressureData, 'date')
        }

        model, date_field = model_mapping[data_type]

        # Base query
        query = Q()
        if line_name:
            query &= Q(line__name=line_name)
        if machine_name:
            query &= Q(machine__name=machine_name)
        if date:
            query &= Q(**{f"{date_field}__gte": date})

        # Fetch the records to delete
        records_to_delete = model.objects.filter(query)

        # Count and delete
        count = records_to_delete.count()
        records_to_delete.delete()

        # Output results
        self.stdout.write(f"Deleted {count} records from {model.__name__}.")
        if line_name:
            self.stdout.write(f"Line: {line_name}")
        if machine_name:
            self.stdout.write(f"Machine: {machine_name}")
        if date:
            self.stdout.write(f"Date (from): {date}")
        self.stdout.write("Data cleared successfully.")
