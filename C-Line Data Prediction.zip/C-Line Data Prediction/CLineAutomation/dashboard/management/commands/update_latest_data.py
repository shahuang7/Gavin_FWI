from django.core.management.base import BaseCommand
from django.conf import settings
from datetime import date
from dateutil.relativedelta import relativedelta
import pandas as pd
from dashboard.models import Machine, YieldData, PressureData, ErrorData
from dashboard.utils.db_utils import query_result, query_realtime_df, get_database_connection, query_pressure_max_values, error_data_process
from django.db import transaction

class Command(BaseCommand):
    help = "Update database with the latest data from remote sources based on type."

    def add_arguments(self, parser):
        parser.add_argument(
            '--type',
            type=str,
            choices=['yield', 'pressure', 'error'],
            required=True,
            help="Specify the type of data to update: 'yield', 'pressure', or 'error'."
        )

    def handle(self, *args, **options):
        data_type = options['type']
        if data_type == 'yield':
            self.stdout.write("Updating YieldData...")
            self.update_yield_data()
        elif data_type == 'pressure':
            self.update_pressure_data()
        elif data_type == 'error':
            self.update_error_data()
        elif data_type == 'save':
            self.temp_save()
        elif data_type == 'restore':
            self.temp_remove_restore()

    def update_yield_data(self):
        """
        Iterate over all line-machine combinations, verify database connection and query success,
        remove rows with the latest date only if data is fetched, and insert the results back.
        """
        db_info = settings.REMOTE_DB_INFO  # Load database connection info
        machines = Machine.objects.all()  # Get all line-machine combinations

        for machine in machines:
            line_name = machine.line.name
            machine_name = machine.name

            self.stdout.write(f"\nProcessing Line: {line_name}, Machine: {machine_name} Yield Data")

            # Step 1: Find the latest date for this machine in YieldData
            latest_date = (
                YieldData.objects.filter(line=machine.line, machine=machine)
                .order_by('-date')
                .values_list('date', flat=True)
                .first()
            )
            if not latest_date:
                self.stdout.write(f"No existing data found for Line: {line_name}, Machine: {machine_name}. Skipping this combination.")
                continue

            self.stdout.write(f"Latest date for Line: {line_name}, Machine: {machine_name}: {latest_date}")

            # Step 2: Construct queries for relevant months
            combined_df = pd.DataFrame()
            current_date = date.today()
            month_diff = (current_date.year - latest_date.year) * 12 + (current_date.month - latest_date.month)
            queries = []

            for i in range(month_diff + 1):
                query_date = latest_date + relativedelta(months=i)
                table_name = f"runtimeandyiled_{query_date.year}_{query_date.month:02d}"
                if i == 0:
                    query = f"SELECT * FROM `{table_name}` WHERE Date >= '{latest_date}';"
                else:
                    query = f"SELECT * FROM `{table_name}`;"
                queries.append(query)

            # Step 3: Fetch data from the remote database
            for query in queries:
                try:
                    df = query_realtime_df(db_info, machine_name, line_name, query)
                    if not df.empty:
                        combined_df = pd.concat([combined_df, df], ignore_index=True)
                except Exception as e:
                    self.stdout.write(f"Error fetching data for Line: {line_name}, Machine: {machine_name}: {e}")
                    combined_df = pd.DataFrame()  # Reset to empty in case of error
                    break  # Skip this combination on failure

            # Step 4: Verify data before deletion
            if not combined_df.empty:
                self.stdout.write(f"Fetched {len(combined_df)} rows for Line: {line_name}, Machine: {machine_name}.")
                combined_df = combined_df.rename(columns={
                    "Date": "date",
                    "TimeID": "time_id",
                    "RunTime": "run_time",
                    "StandByTime": "standby_time",
                    "ErrorTime": "error_time",
                    "StopTime": "stop_time",
                    "Yiled": "yield_value"
                })
                combined_df['date'] = pd.to_datetime(combined_df['date']).dt.date

                # Step 5: Remove rows with the latest date
                with transaction.atomic():
                    YieldData.objects.filter(line=machine.line, machine=machine, date=latest_date).delete()
                    self.stdout.write(f"Removed rows for Line: {line_name}, Machine: {machine_name} on {latest_date}.")

                # Step 6: Insert the new data into YieldData
                rows_to_insert = [
                    YieldData(
                        line=machine.line,
                        machine=machine,
                        date=row['date'],
                        time_id=row['time_id'],
                        run_time=row['run_time'],
                        standby_time=row['standby_time'],
                        error_time=row['error_time'],
                        stop_time=row['stop_time'],
                        yield_value=row['yield_value']
                    )
                    for _, row in combined_df.iterrows()
                ]
                with transaction.atomic():
                    YieldData.objects.bulk_create(rows_to_insert, batch_size=1000)
                self.stdout.write(f"Inserted {len(rows_to_insert)} rows for Line: {line_name}, Machine: {machine_name}.")
            else:
                self.stdout.write(f"No new data found or data fetch failed for Line: {line_name}, Machine: {machine_name}. Skipping deletion.")

    def update_pressure_data(self):
        """
        Iterate over all line-machine combinations, fetch maximum pressure values, 
        remove old data, and insert the results back into the database.
        """
        machines = Machine.objects.all()  # Testing with C3-aoi

        for machine in machines:
            line_name = machine.line.name
            machine_name = machine.name

            self.stdout.write(f"\nProcessing Line: {line_name}, Machine: {machine_name} Pressure Data")

            # Step 1: Find the latest date for this machine in PressureData
            latest_date = (
                PressureData.objects.filter(line=machine.line, machine=machine)
                .order_by('-date')
                .values_list('date', flat=True)
                .first()
            )
            if not latest_date:
                self.stdout.write(f"No existing data found for {machine.line.name} - {machine.name}. Skipping...")
                continue

            self.stdout.write(f"Latest date for {machine.line.name} - {machine.name}: {latest_date}")

            # Step 2: Fetch data from the remote database
            combined_df = self.fetch_pressure_data(machine, latest_date)
            if combined_df.empty:
                self.stdout.write(f"No new data found or data fetch failed for {machine.line.name} - {machine.name}.")
                continue
            self.stdout.write(f"Fetched {len(combined_df)} rows for {machine.line.name} - {machine.name}.")
            # # Step 3: Remove old data and insert new data
            with transaction.atomic():
                PressureData.objects.filter(line=machine.line, machine=machine, date__gte=latest_date).delete()
                self.stdout.write(f"Removed old rows for {machine.line.name} - {machine.name} after {latest_date}.")

                rows_to_insert = [
                    PressureData(
                        line=machine.line,
                        machine=machine,
                        date=row['date'],
                        time=row['time'],
                        product_sn=row['product_sn'],
                        type=row['type'],
                        num=row['num'],
                        max_value=row['max_value']
                    )
                    for _, row in combined_df.iterrows()
                ]
                # for row in rows_to_insert[-10:]:
                #     print(f"Max Value to be inserted: {row.max_value}")  # This should now reflect the full precision
                PressureData.objects.bulk_create(rows_to_insert, batch_size=1000)
                self.stdout.write(f"Inserted {len(rows_to_insert)} rows for {machine.line.name} - {machine.name}.")

    def fetch_pressure_data(self, machine, latest_date):
        """
        Fetch pressure data from the remote database for the specified machine-line combination.

        Parameters:
            machine: Machine instance containing line and machine names.
            latest_date: Latest date in the database.

        Returns:
            Processed DataFrame.
        """
        current_date = date.today()
        month_diff = (current_date.year - latest_date.year) * 12 + (current_date.month - latest_date.month)
        combined_df = pd.DataFrame()

        line_name = machine.line.name
        machine_name = machine.name

        for i in range(month_diff + 1):
            query_date = latest_date + relativedelta(months=i)
            table_name = f"dimmpressure_{query_date.year}_{query_date.month:02d}"

            # Use get_database_connection to establish the connection
            connection, connection_type = get_database_connection(line_name, machine_name)
            if not connection:
                self.stdout.write(f"Skipping {line_name} - {machine_name} due to connection issues.")
                continue

            try:
                with connection:
                    # Fetch data for the specific table using query_pressure_max_values
                    df = query_pressure_max_values(
                        connection,
                        [table_name],
                        latest_date if i == 0 else None  # Apply `WHERE` clause only for the first month
                    )
                    if not df.empty:
                        combined_df = pd.concat([combined_df, df], ignore_index=True)
            except Exception as e:
                self.stdout.write(f"Error fetching data for {line_name} - {machine_name} in table {table_name}: {e}")
                continue
            finally:
                connection.close()

        # Process and rename columns if data exists
        if not combined_df.empty:
            combined_df = combined_df.rename(columns={
                "Date": "date",
                "Time": "time",
                "ProductSN": "product_sn",
                "Type": "type",
                "Num": "num",
                "MaxValue": "max_value"
            })

            # combined_df['max_value'] = combined_df['max_value'].apply(lambda x: Decimal(str(x)) if not pd.isnull(x) else None)
        return combined_df

    def update_error_data(self):
        """
        Update error data for all line-machine combinations.
        """
        # Fetch all machines
        machines = Machine.objects.all()

        for machine in machines:
            line_name = machine.line.name
            machine_name = machine.name

            self.stdout.write(f"\nProcessing Line: {line_name}, Machine: {machine_name} Error Data")

            # Step 1: Find the latest start_date for this machine in ErrorData
            latest_date = (
                ErrorData.objects.filter(line=machine.line, machine=machine)
                .order_by('-start_date')
                .values_list('start_date', flat=True)
                .first()
            )
            if not latest_date:
                self.stdout.write(f"No existing data found for Line: {line_name}, Machine: {machine_name}. Skipping...")
                continue

            self.stdout.write(f"Latest start_date for Line: {line_name}, Machine: {machine_name}: {latest_date}")

            # Step 2: Determine monthly tables to query
            current_date = date.today()
            month_diff = (current_date.year - latest_date.year) * 12 + (current_date.month - latest_date.month)
            combined_df = pd.DataFrame()

            connection, connection_type = get_database_connection(line_name, machine_name)
            if not connection:
                self.stdout.write(f"Failed to connect to database for {line_name}-{machine_name}. Skipping...")
                continue

            try:
                for i in range(month_diff + 1):
                    query_date = latest_date + relativedelta(months=i)
                    table_name = f"errorcode_{query_date.year}_{query_date.month:02d}"
                    query = f"SELECT * FROM `{table_name}` WHERE StartDate >= '{latest_date}'" if i == 0 else f"SELECT * FROM `{table_name}`;"
                    
                    try:
                        monthly_df = query_result(connection, connection_type, query)
                        if not monthly_df.empty:
                            combined_df = pd.concat([combined_df, monthly_df], ignore_index=True)
                    except Exception as e:
                        self.stdout.write(f"Error querying {table_name} for {line_name}-{machine_name}: {e}")
                        continue
            finally:
                connection.close()

            if combined_df.empty:
                self.stdout.write(f"No new data found for Line: {line_name}, Machine: {machine_name}.")
                continue

            # Step 3: Fetch error definitions and process the data
            try:
                error_def_query = "SELECT * FROM errorcodedef"
                connection, connection_type = get_database_connection(line_name, machine_name)
                error_def_df = query_result(connection, connection_type, error_def_query)

                # Dynamic error code file
                if machine_name.startswith("dimm"):
                    error_code_file = "dashboard/real_time_data/dimm_error_code_def.csv"
                elif machine_name == "powerfan":
                    error_code_file = "dashboard/real_time_data/powerfan_error_code_def.csv"
                elif machine_name == "aoi":
                    error_code_file = "dashboard/real_time_data/aoi_error_code_def.csv"
                else:
                    self.stdout.write(f"Unknown machine type for {machine_name}. Skipping...")
                    continue

                error_code_df = pd.read_csv(error_code_file)
                processed_df = error_data_process(error_code_df, error_def_df, combined_df)

                # Rename columns in the processed DataFrame to match the model fields
                processed_df.rename(columns={
                    'StartDate': 'start_date',
                    'StartTime': 'start_time',
                    'EndDate': 'end_date',
                    'EndTime': 'end_time',
                    'DescID': 'desc_id',
                    'Error_Code': 'error_code',
                    'Error_Chinese_Def': 'error_chinese_def',
                    'Error_English_Def': 'error_english_def',
                    'Error_Def': 'error_def'
                }, inplace=True)
                # Step 4: Remove old data and insert new data
                with transaction.atomic():
                    ErrorData.objects.filter(line=machine.line, machine=machine, start_date__gte=latest_date).delete()
                    self.stdout.write(f"Removed old rows for Line: {line_name}, Machine: {machine_name} from {latest_date} onwards.")

                    rows_to_insert = [
                        ErrorData(
                            line=machine.line,
                            machine=machine,
                            start_date=row['start_date'],
                            end_date=row['end_date'],
                            start_time=row['start_time'],
                            end_time=row['end_time'],
                            desc_id=row['desc_id'],
                            error_code=row['error_code'],
                            error_chinese_def=row['error_chinese_def'],
                            error_english_def=row['error_english_def'],
                            error_def=row['error_def']
                        )
                        for _, row in processed_df.iterrows()
                    ]
                    ErrorData.objects.bulk_create(rows_to_insert, batch_size=1000)
                    self.stdout.write(f"Inserted {len(rows_to_insert)} rows for Line: {line_name}, Machine: {machine_name}.")
            except Exception as e:
                self.stdout.write(f"Error processing data for {line_name}-{machine_name}: {e}")

