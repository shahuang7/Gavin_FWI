let currentLineName = "";
let currentDate = "";
let currentMachine = "POWERFAN"; // Track the currently active machine
import { formatDuration } from "./line-details.js";

export function initializeYieldTab(lineName) {
    console.log(`Initializing Yield Tab for line: ${lineName}`);
    currentLineName = lineName;
    currentDate = new Date().toLocaleDateString("en-CA"); // Default to today's date
    const datePicker = document.getElementById("yield-date");
    if (datePicker) {
        datePicker.value = currentDate;

        // Attach change listener to the date picker
        datePicker.addEventListener("change", () => {
            currentDate = datePicker.value;

            // Reset slider for historical dates or update for today's date
            const isToday = new Date(currentDate).toLocaleDateString("en-CA") === new Date().toLocaleDateString("en-CA");
            const now = new Date();
            const currentHour = now.getHours();
            const endHour = isToday ? currentHour : 24;
            const timeSlider = document.getElementById("time-slider").noUiSlider;
            if (timeSlider) {
                timeSlider.updateOptions({
                    start: [7, endHour], // Reset the range
                    range: {
                        min: 0,
                        max: 24
                    }
                });
            }

            fetchAndRenderYieldData(); // Re-fetch data when the date changes
        });
    }

    const machines = ["POWERFAN", "DIMM1", "DIMM2", "DIMM3", "AOI"];
    initializeYieldSubTabs(machines);
    initializeTimeSlider(datePicker.value);
    fetchAndRenderYieldData();

    // Start periodic updates every minute only when the tab is active
    function startTimelyUpdates() {
        const POLL_INTERVAL = 60000; // 1 minute in milliseconds
        let intervalId = null;

        const checkActiveTab = () => {
            const activeTab = document.querySelector(".tab.active");
            if (activeTab && activeTab.getAttribute("data-tab") === "yield") {
                if (!intervalId) {
                    console.log("Starting periodic updates for Yield Tab...");
                    intervalId = setInterval(() => {
                        console.log("Fetching periodic updates...");
                        currentDate = new Date().toLocaleDateString("en-CA");
                        if (datePicker) {
                            datePicker.value = currentDate;
                        }
                        fetchAndRenderYieldData();
                    }, POLL_INTERVAL);
                }
            } else {
                if (intervalId) {
                    console.log("Stopping periodic updates for Yield Tab...");
                    clearInterval(intervalId);
                    intervalId = null;
                }
            }
        };

        document.querySelectorAll(".tab").forEach(tab => {
            tab.addEventListener("click", checkActiveTab);
        });

        checkActiveTab();
    }

    startTimelyUpdates();
}


function initializeYieldSubTabs(machines) {
    const subTabContainer = document.querySelector(".sub-tab-container");
    if (subTabContainer) {
        subTabContainer.innerHTML = ""; // Clear existing sub-tabs if any

        machines.forEach((machine, index) => {
            const subTab = document.createElement("div");
            subTab.classList.add("sub-tab");
            if (index === 0) subTab.classList.add("active"); // Activate the first sub-tab
            subTab.setAttribute("data-machine", machine);
            subTab.textContent = machine;

            subTab.addEventListener("click", () => {
                // Update the active machine
                currentMachine = machine;

                // Handle Sub-Tab Activation
                document.querySelectorAll(".sub-tab").forEach(tab => tab.classList.remove("active"));
                subTab.classList.add("active");
                // Fetch and render data for the selected machine
                fetchAndRenderYieldData();
            });

            subTabContainer.appendChild(subTab);
        });
    }
}

function fetchAndRenderYieldData() {
    showLoadingScreen();
    const yieldPlotContainer = document.getElementById("yield-plot-container");

    // Reset the container to prevent stale state
    if (yieldPlotContainer) {
        yieldPlotContainer.innerHTML = `
            <div class="gauge-plot-container">
                <div id="yield-amount" class="yield-text"></div>
                <div id="gauge-plot-1" class="gauge-plot"></div>
                <div id="gauge-plot-2" class="gauge-plot"></div>
            </div>
            <div id="stacked-bar-plot" class="bar-plot"></div>
        `;
    }

    const timeSlider = document.getElementById("time-slider").noUiSlider;
    const timeRange = timeSlider.get(); // Get the slider range
    const startTimeID = parseInt(timeRange[0], 10) + 1; // Start TimeID (1-based)
    let sliderEndTimeID = parseInt(timeRange[1], 10); // End TimeID based on slider

    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();

    // Calculate the actual current TimeID
    const actualCurrentTimeID = currentMinute > 0 ? currentHour + 1 : currentHour;

    console.log(`Fetching yield data for line: ${currentLineName}, machine: ${currentMachine}, date: ${currentDate}`);

    fetch(`/line/${currentLineName}/yield-data/?date=${currentDate}&machine=${currentMachine}`)
        .then(response => {
            if (!response.ok) throw new Error("Failed to fetch yield data.");
            return response.json();
        })
        .then(data => {
            const { filtered_data, is_today } = data;
            if (!filtered_data || filtered_data.length === 0) {
                yieldPlotContainer.innerHTML = `
                    <p style="text-align: center; color: red; font-size: 18px;">
                        No Data Found. Please try other machines.
                    </p>`;
                return;
            }

            // Adjust endTimeID based on `is_today` flag
            let endTimeID = is_today
                ? Math.min(sliderEndTimeID, actualCurrentTimeID) // Cap slider end to current time for today
                : sliderEndTimeID; 
            console.log(`Start TimeID: ${startTimeID}, Slider End TimeID: ${sliderEndTimeID}, Actual Current TimeID: ${actualCurrentTimeID}`, `Adjusted End TimeID for Whole Day: ${endTimeID}`);
            
            // Calculate Total Yield
            const totalYield = calculateTotalYield(filtered_data);

            // Find the container and update its content
            const yieldSum = document.getElementById("yield-amount");
            if (yieldSum) {
                yieldSum.innerHTML = `
                    <p>Total Yield: <br><br><strong>${totalYield}</strong> pieces</p>
                `;
            } else {
                console.error("Yield amount container not found.");
            }

            // Filter the data for the current OEE calculation
            const currentOEE = calculateOEE(filtered_data, true, actualCurrentTimeID, is_today); // Always use actual time for current OEE

            // Filter the data for the whole day OEE calculation
            const wholeDayOEE = calculateOEE(filtered_data, false, { startTimeID, endTimeID }, is_today); // Use adjusted endTimeID for whole day OEE

            // Update gauge plots
            const gaugePlot1 = document.getElementById("gauge-plot-1");
            const gaugePlot2 = document.getElementById("gauge-plot-2");

            if (!gaugePlot1 || !gaugePlot2) {
                console.error("Gauge plot containers not found.");
                return;
            }

            renderOEEPlots(gaugePlot1, currentOEE, "Current OEE");
            renderOEEPlots(gaugePlot2, wholeDayOEE, "Whole Day OEE");

            // Render yield plots
            renderYieldPlots(currentMachine, filtered_data);
        })
        .catch(error => {
            console.error("Error fetching yield data:", error);
            yieldPlotContainer.innerHTML = `
                <p style="text-align: center; color: red; font-size: 18px;">
                    Error fetching yield data. Please try again later.
                </p>`;
        })
        .finally(() => {
            hideLoadingScreen(); // Always hide the loading screen after processing
        });
}

function calculateTotalYield(filteredData) {
    // Sum up all Yield values
    const totalYield = filteredData.reduce((sum, row) => sum + (row.Yield || 0), 0);
    return totalYield;
}

function renderYieldPlots(machine, filteredData) {
    const barPlot = document.getElementById("stacked-bar-plot");

    if (!barPlot) {
        console.error("Stacked bar plot container not found.");
        return;
    }

    if (filteredData && filteredData.length > 0) {
        const { barData, timeLabels, yieldData } = generateStackedBarData(filteredData);

        // Consolidate hover information for each timeLabel
        barData.forEach((trace) => {
            trace.hoverinfo = "skip"; // Disable individual hover boxes
        });

        // Calculate stacked bar heights and add annotations for Yield values
        const annotations = yieldData.map((yieldValue, index) => {
            // Sum up the bar heights for the current time index
            const totalHeight = barData.reduce((sum, trace) => sum + trace.y[index], 0);
            return {
                x: timeLabels[index],
                y: totalHeight, // Top of the stacked bars
                text: "Yield: "+yieldValue.toString(), // Yield value as text
                showarrow: false,
                font: { color: "black", size: 10 },
                xref: "x", // Reference the x-axis
                yref: "y", // Reference the y-axis
                yanchor: "bottom",
            };
        });
        
        const consolidatedHoverData = timeLabels.map((timeLabel, index) => {
            const lines = barData
                .map((trace) => {
                    const value = trace.y[index];
                    return value > 0
                        ? `${trace.name}: ${formatDuration(value)}`
                        : null;
                })
                .filter(Boolean)
                .join("<br>");
            return `${timeLabel}<br>${lines}`;
        });

        // Add consolidated hover template to the first trace
        barData[0].hoverinfo = "text"; // Enable hover for the first trace
        barData[0].text = consolidatedHoverData;

        const layout = {
            barmode: "stack",
            xaxis: {
                tickmode: "array",
                tickvals: timeLabels,
                ticktext: timeLabels,
            },
            yaxis: { title: { text: "Total Time (seconds)", font: { size: 14 } } },
            legend: {
                orientation: "h",
                x: 0.5,
                y: 1.1,
                xanchor: "center",
                yanchor: "top",
            },
            margin: { t: 20, b: 60, l: 50, r: 50 },
            annotations: annotations, // Add annotations to the layout
        };

        Plotly.react(barPlot, barData, layout, { responsive: true });
    } else {
        barPlot.innerHTML = `<p>No data available for the bar plot for ${machine}.</p>`;
    }
}

function generateStackedBarData(filteredData) {
    const timeRanges = {};

    for (let i = 1; i <= 24; i++) {
        const startHour = String(i - 1).padStart(2, "0");
        const endHour = String(i % 24).padStart(2, "0");
        timeRanges[i] = `${startHour}:00-${endHour}:00`;
    }

    const runtime = filteredData.map(row => row.RunTime || 0);
    const standbyTime = filteredData.map(row => row.StandByTime || 0);
    const errorTime = filteredData.map(row => row.ErrorTime || 0);
    const stopTime = filteredData.map(row => row.StopTime || 0);
    const yieldData = filteredData.map(row => row.Yield || 0); // Extract Yield
    const timeLabels = filteredData.map(row => timeRanges[row.TimeID] || "");

    return {
        barData: [
            { x: timeLabels, y: runtime, name: "Run Time", type: "bar", marker: { color: "#58D68D" } },
            { x: timeLabels, y: standbyTime, name: "Standby Time", type: "bar", marker: { color: "#F7DC6F" } },
            { x: timeLabels, y: errorTime, name: "Error Time", type: "bar", marker: { color: "#EC7063" } },
            { x: timeLabels, y: stopTime, name: "Stop Time", type: "bar", marker: { color: "#AAB7B8" } },
        ],
        timeLabels,
        yieldData, // Pass Yield data for annotation
    };
}

function renderOEEPlots(gaugePlot, oeeValues, title) {
    const generateGaugeData = (value) => ({
        type: "indicator",
        mode: "gauge+number",
        value: value, // This will be animated
        number: {
            font: { 
                size: 30, 
                color: value < 30 ? "#ff7f7f" : value < 70 ? "#ffdd57" : "#4da3ff" 
            },
            suffix: "%", // Adds percentage symbol to the value
            format: ".2f", // Ensures two decimal places are shown
        },
        gauge: {
            axis: { range: [0, 100], tickwidth: 1, tickcolor: "darkgray" },
            bar: { color: value < 30 ? "#ff7f7f" : value < 70 ? "#ffdd57" : "#4da3ff" },
            steps: [
                { range: [0, 30], color: "#ffe6e6" },
                { range: [30, 70], color: "#fff8c4" },
                { range: [70, 100], color: "#d2e9ff" },
            ],
        },
    });
    
    const generateGaugeLayout = (titleText) => ({
        margin: { t: 0, b: 0, l: 30, r: 30 }, // Compact margins
        paper_bgcolor: "white",
        annotations: [
            {
                x: 0.5, // Center horizontally
                y: 0.4, // Position above the value
                xanchor: "center",
                yanchor: "center",
                text: `<b>${titleText}</b>`, // Bold title text
                showarrow: false,
                font: { size: 16, color: "gray" },
            },
        ],
    });

    const animateGauge = (container, value, layout) => {
        let currentValue = 0;
        const increment = value / 50; // Number of steps to animate
        const duration = 20; // Duration of each step in milliseconds
    
        const step = () => {
            if (currentValue < value) {
                currentValue = Math.min(currentValue + increment, value); // Increment and ensure no overshoot
            } else {
                currentValue = value; // Ensure exact final value
            }
            const data = [generateGaugeData(currentValue)];
            Plotly.react(container, data, layout, { responsive: true });
            if (currentValue < value) {
                setTimeout(step, duration); // Schedule the next step
            }
        };
    
        // Start the animation or render instantly for 0
        if (value === 0) {
            const data = [generateGaugeData(0)];
            Plotly.react(container, data, layout, { responsive: true });
        } else {
            step();
        }
    };
    
    
    // Animate OEE Gauge
    animateGauge(
        gaugePlot,
        oeeValues,
        generateGaugeLayout(title)
    );

}

function showLoadingScreen() {
    const loadingScreen = document.querySelector("#yield-plot-container #loading-screen");
    const yieldGaugeContainer = document.getElementById("gauge-plot-container");
    const yieldBarContainer = document.getElementById("stacked-bar-plot");

    if (loadingScreen) {
        loadingScreen.classList.remove("hidden"); // Show the loading screen
    }
    if (yieldGaugeContainer) {
        yieldGaugeContainer.classList.add("hidden"); // Hide the duration text
    }
    if (yieldBarContainer) {
        yieldBarContainer.classList.add("hidden"); // Hide the plot container
    }
}

function hideLoadingScreen() {
    const loadingScreen = document.querySelector("#yield-plot-container #loading-screen");
    const yieldGaugeContainer = document.getElementById("gauge-plot-container");
    const yieldBarContainer = document.getElementById("stacked-bar-plot");

    if (loadingScreen) {
        loadingScreen.classList.add("hidden"); // Hide the loading screen
    }
    if (yieldGaugeContainer) {
        yieldGaugeContainer.classList.remove("hidden"); // Show the duration text
    }
    if (yieldBarContainer) {
        yieldBarContainer.classList.remove("hidden"); // Show the plot container
    }
}

/**
 * Calculate OEE values for the machine.
 * 
 * @param {Array} data - Array of machine data objects, each containing `RunTime`, `StandByTime`, `ErrorTime`, `StopTime`.
 * @param {boolean} isCurrent - If true, calculates OEE for the current time ID, otherwise for the whole day.
 * @param {Object|number} timeRange - Either the `currentTimeID` (for current OEE) or an object `{ startTimeID, endTimeID }` (for whole day OEE).
 * @param {boolean} isToday - If true, limits whole day OEE to the current time ID.
 * @returns {number} - The calculated OEE value.
 */
function calculateOEE(data, isCurrent, timeRange, isToday) {
    if (!data || data.length === 0) {
        console.error("Invalid data provided for OEE calculation.");
        return 0;
    }
    let runTime = 0;
    let standbyTime = 0;
    let errorTime = 0;
    let stopTime = 0;

    if (isCurrent) {
        // Use only the current time ID's data
        const currentData = data.find(row => row.TimeID === timeRange);
        if (!currentData) {
            console.error(`No data found for TimeID: ${timeRange}`);
            return 0;
        }
        runTime = currentData.RunTime;
        standbyTime = currentData.StandByTime;
        errorTime = currentData.ErrorTime;
        stopTime = currentData.StopTime;
    } else {
        // For whole day OEE
        const { startTimeID, endTimeID } = timeRange;

        // Adjust endTimeID for today if it exceeds the currentTimeID
        const adjustedEndTimeID = isToday
            ? Math.min(endTimeID, new Date().getHours() + 1) // Cap at current TimeID
            : endTimeID;

        // Filter data based on the slider range
        const filteredData = data.filter(
            row => row.TimeID >= startTimeID && row.TimeID <= adjustedEndTimeID // Exclude future data
        );
        filteredData.forEach(row => {
            runTime += row.RunTime;
            standbyTime += row.StandByTime;
            errorTime += row.ErrorTime;
            stopTime += row.StopTime;
        });
    }

    const totalTime = runTime + standbyTime;
    const sumOfTimes = runTime + standbyTime + errorTime + stopTime;

    // Calculate OEE
    const oee = sumOfTimes > 0 ? (totalTime / sumOfTimes) * 100 : 0;
    return parseFloat(oee.toFixed(2)); // Return OEE with two decimal places
}

function initializeTimeSlider(dateValue) {
    const timeSlider = document.getElementById("time-slider");
    const timeDisplay = document.getElementById("time-range-display");
    const currentDate = new Date().toLocaleDateString("en-CA");
    const isToday = currentDate === dateValue;

    const now = new Date();
    const currentHour = now.getHours();
    const currentMinute = now.getMinutes();

    const currentTimeID = currentMinute > 0 ? currentHour + 1 : currentHour;
    const endHour = isToday ? currentTimeID : 24;
    noUiSlider.create(timeSlider, {
        start: [7, endHour],
        connect: true,
        range: {
            min: 0,
            max: 24 // Always allow full-day range
        },
        step: 1,
        format: {
            to: value => (value >= 24 ? 24 : Number(value.toFixed(0))),
            from: value => parseInt(value, 10)
        }
    });

    const updateTimeRangeDisplay = (values) => {
        const startTime = `${String(values[0]).padStart(2, '0')}:00`;
        const endTime = values[1] === 24 
            ? (isToday ? '24:00' : '23:59')
            : `${String(values[1]).padStart(2, '0')}:00`;
        timeDisplay.textContent = `${startTime} - ${endTime}`;
    };

    timeSlider.noUiSlider.on("update", function (values) {
        updateTimeRangeDisplay(values);
    });

    timeSlider.noUiSlider.on("change", function () {
        fetchAndRenderYieldData();
    });

    // Dynamically adjust the slider's upper bound if it's today
    if (isToday) {
        setInterval(() => {
            const now = new Date();
            const currentHour = now.getHours();
            const currentMinute = now.getMinutes();
            // Dynamically calculate the current TimeID
            const dynamicTimeID = currentMinute > 0 ? currentHour + 1 : currentHour;

            timeSlider.noUiSlider.updateOptions({
                range: { min: 0, max: 24 }
            });
            timeSlider.noUiSlider.set([7, dynamicTimeID]); // Default start at 07:00, adjust end dynamically
        }, 60000); // Update every minute
    }

    updateTimeRangeDisplay([7, endHour]);
}















