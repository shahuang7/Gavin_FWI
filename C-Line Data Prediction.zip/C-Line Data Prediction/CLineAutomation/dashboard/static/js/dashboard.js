document.addEventListener("DOMContentLoaded", function () { 
    const loadingScreen = document.getElementById("loading-screen");
    const mainContent = document.getElementById("main-content");
    const updateButton = document.getElementById("filter-button");
    let isUpdateAction = false; // Flag to track if it's an update action

    // Function to fetch and render dashboard data
    function fetchAndRenderData() {
        showLoadingScreen(); // Show loading screen before the fetch starts
        fetch("/fetch-dashboard-data/")
            .then(response => response.json())
            .then(data => renderDashboard(data))
            .catch(error => showError(error))
            .finally(() => hideLoadingScreen()); // Hide loading screen after processing
    }

    // Function to update plots
    function updateDashboardData() {
        isUpdateAction = true; // Set the flag for update action
        const selectedDate = document.getElementById("date-picker").value;
        const selectedTimeSlot = document.getElementById("time-slot-dropdown").value;
        const selectedMachines = Array.from(
            document.querySelectorAll(".machine-selection input[name='machines']:checked")
        ).map(checkbox => checkbox.value);

        const payload = { date: selectedDate, time_slot: selectedTimeSlot, machines: selectedMachines };

        showLoadingScreen(); // Show loading screen before sending the POST request
        fetch("/fetch-dashboard-data/", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload),
        })
            .then(response => response.json())
            .then(data => renderDashboard(data))
            .catch(error => showError(error))
            .finally(() => hideLoadingScreen()); // Hide loading screen after processing
    }

    // Render the dashboard with fetched data
    function renderDashboard(data) {
        if (data.error) {
            console.error("Error loading data:", data.error);
            return;
        }
        
        // Only populate filters on initial load, not on update action
        if (!isUpdateAction) {
            const currentHour = new Date().getHours(); // Get the current hour (0-23)
            const currentTimeSlot = `${currentHour.toString().padStart(2, '0')}:00-${(currentHour + 1).toString().padStart(2, '0')}:00`;
            populateFilters(data.lines, data.machines, data.current_date, currentTimeSlot); // Pass currentTimeSlot
        }

        // Determine whether fetching today's data
        const isToday = data.is_today;

        resetGridLayout();
        generateYieldandOEEPlots(data.data, isToday); // Use filtered data for plotting
        // observeGaugeResize();
        mainContent.classList.remove("hidden");
        isUpdateAction = false; // Reset the flag after rendering
    }
    // Show error on the page
    function showError(error) {
        console.error("Error:", error);
        loadingScreen.innerHTML = "<p>Failed to load data. Please try again.</p>";
    }

    // Initial fetch
    fetchAndRenderData();

    // Event listener for the update button
    updateButton.addEventListener("click", updateDashboardData);

    // Start periodic updates every minute
    function startTimelyUpdates() {
        const POLL_INTERVAL = 60000; // 1 minute in milliseconds
        setInterval(() => {
            console.log("Fetching periodic updates...");
            fetchAndRenderData();
        }, POLL_INTERVAL);
    }

    startTimelyUpdates();
});

// Trigger resize when the window size changes
window.addEventListener("resize", function () {
    resizePlots();
});

// Populate filters dynamically
function populateFilters(lines, machines, currentDate, currentTime) {
    const lineDropdown = document.getElementById("line-dropdown");
    const machinesContainer = document.querySelector(".machine-selection");
    const datePicker = document.getElementById("date-picker");
    const timeSlotDropdown = document.getElementById("time-slot-dropdown");

    // Line dropdown
    lineDropdown.innerHTML = `<option value="all">All Lines</option>`;
    lines.forEach(line => {
        lineDropdown.innerHTML += `<option value="${line}">${line}</option>`;
    });

    // Machine checkboxes
    machinesContainer.innerHTML = "";
    machines.forEach(machine => {
        machinesContainer.innerHTML += `
            <label>
                <input type="checkbox" name="machines" value="${machine}" checked>
                ${machine.charAt(0).toUpperCase() + machine.slice(1)}
            </label>`;
    });

    // Date picker
    datePicker.value = currentDate;

    // Populate time slot dropdown
    const currentTimeInt = parseInt(currentTime, 10);
    timeSlotDropdown.innerHTML = "";
    for (let hour = 0; hour < 24; hour++) {
        const startHour = hour.toString().padStart(2, "0");
        const endHour = (hour + 1).toString().padStart(2, "0");
        const option = document.createElement("option");
        option.value = hour;
        option.textContent = `${startHour}:00 - ${endHour}:00`;
        if (hour === currentTimeInt) {
            option.selected = true; // Dynamically select the current time slot
        }
        timeSlotDropdown.appendChild(option);
    }
}

// Generate bar plots for all lines
function generateYieldandOEEPlots(filteredData, isToday) {
    if (!filteredData || filteredData.length === 0) {
        console.error("Error: Filtered data is empty or undefined.");
        return;
    }

    const plotsContainer = document.getElementById("plots-container");
    plotsContainer.innerHTML = ''; // Clear previous content to avoid duplicates
    const lines = ['C1', 'C2', 'C3', 'C4', 'C5', 'C6'];
    const selectedTimeSlot = Number(document.getElementById("time-slot-dropdown").value);

    lines.forEach(line => {
        // Filter data for the current line
        const lineData = filterDataByLine(filteredData, line);
        const currentData = lineData.filter(row => row.TimeID === selectedTimeSlot + 1);

        // Create the dashboard cell
        const dashboardCell = document.createElement("div");
        dashboardCell.classList.add("dashboard-cell");

        // Add title
        const title = document.createElement("h3");
        title.textContent = `Line: ${line}`;
        dashboardCell.appendChild(title);

        // Add time slider container
        const timeSliderContainer = document.createElement("div");
        timeSliderContainer.classList.add("time-slider-container");

        const timeSliderLabel = document.createElement("label");
        timeSliderLabel.setAttribute("for", `time-slider-${line}`);
        timeSliderLabel.innerHTML = `Whole Day OEE Time Range: 
            <span id="time-range-display-${line}">07:00 - ${isToday ? `${new Date().getHours()+1}:00` : "24:00"}</span>`;
        timeSliderContainer.appendChild(timeSliderLabel)        

        const timeSlider = document.createElement("div");
        timeSlider.setAttribute("id", `time-slider-${line}`);
        timeSlider.setAttribute("data-current-date", true);
        timeSliderContainer.appendChild(timeSlider);

        // Add gauge container
        const gaugeContainer = document.createElement("div");
        gaugeContainer.classList.add("gauge-container");

        const currentOEEContainer = document.createElement("div");
        const wholeDayOEEContainer = document.createElement("div");
        gaugeContainer.appendChild(currentOEEContainer);
        gaugeContainer.appendChild(wholeDayOEEContainer);

        initializeTimeSlider(timeSlider, line, isToday, lineData, wholeDayOEEContainer); // change here
        dashboardCell.appendChild(timeSliderContainer);
        dashboardCell.appendChild(gaugeContainer);

        // Calculate current OEE
        const { machineOEE, lineCurrentOEE } = calculateLineOEE(currentData, true, selectedTimeSlot + 1, isToday);
        // Add flip card
        const flipCard = createFlipCard(currentData, machineOEE);
        dashboardCell.appendChild(flipCard);

        // Append to the plots container
        plotsContainer.appendChild(dashboardCell);

        // Generate gauge plots
        generateGaugePlot(currentOEEContainer, "Hourly OEE", lineCurrentOEE);
        // Initial calculation of Daily OEE
        const initialTimeRange = { startTimeID: 8, endTimeID: 24 };
        updateDailyOEEGauge(lineData, initialTimeRange, wholeDayOEEContainer, isToday);
    });

    // Ensure reflow and resize plots
    setTimeout(() => {
        resizePlots();
    }, 0);
}

function filterDataByLine(data, line) {
    return data.filter(row => row.line === line); // Adjust this logic based on your data structure
}

function calculateLineOEE(lineData, isCurrent, timeRange, isToday) {
    if (!lineData || lineData.length === 0) {   
        return isCurrent
            ? { machineOEE: {}, lineCurrentOEE: 0 }
            : { lineWholeDayOEE: 0 };
    }

    let machineOEE = {}; // Store OEE for each machine
    let totalOEE = 0; // Aggregate OEE for all machines
    let totalMachines = 0; // Count of machines

    if (isCurrent) {
        if (!lineData || lineData.length === 0) {
            console.error("No data found for TimeID: ${timeRange}");
            return { machineOEE: {}, line_current_oee: 0 };
        }

        lineData.forEach(row => {
            const { machine, RunTime = 0, StandByTime = 0, ErrorTime = 0, StopTime = 0 } = row;

            const totalTime = RunTime + StandByTime;
            const sumOfTimes = RunTime + StandByTime + ErrorTime + StopTime;

            const oee = sumOfTimes > 0 ? (totalTime / sumOfTimes) * 100 : 0;
            machineOEE[machine] = parseFloat(oee.toFixed(2)); // Store per-machine OEE
            totalOEE += oee;
            totalMachines++;
        });

        const lineOEE = totalMachines > 0 ? totalOEE / totalMachines : 0;
        return {
            machineOEE,
            lineCurrentOEE: parseFloat(lineOEE.toFixed(2)), // Return current OEE as a single value
        };
    } else {
        // For whole day OEE
        const { startTimeID, endTimeID } = timeRange;
        const adjustedEndTimeID = isToday
            ? Math.min(endTimeID, new Date().getHours() + 1) // Cap at current TimeID
            : endTimeID;

        // Filter data based on the time range
        const filteredData = lineData.filter(
            row => row.TimeID >= startTimeID && row.TimeID <= adjustedEndTimeID
        );
        let runTime = 0;
        let standbyTime = 0;
        let errorTime = 0;
        let stopTime = 0;

        filteredData.forEach(row => {
            runTime += row.RunTime || 0;
            standbyTime += row.StandByTime || 0;
            errorTime += row.ErrorTime || 0;
            stopTime += row.StopTime || 0;
        });

        const totalTime = runTime + standbyTime;
        const sumOfTimes = runTime + standbyTime + errorTime + stopTime;

        const lineOEE = sumOfTimes > 0 ? (totalTime / sumOfTimes) * 100 : 0;

        return {
            lineWholeDayOEE: parseFloat(lineOEE.toFixed(2)), // Return daily OEE as a single value
        };
    }
}

function generateOEEPlotData(machineOEE, container) {
    // Define all expected machine keys
    const expectedKeys = ['powerfan', 'dimm1', 'dimm2', 'dimm3', 'aoi'];

    // Ensure all keys are included in the data, default to 0 if missing
    const fullOEEData = expectedKeys.map(key => ({
        machine: key,
        oee: machineOEE[key] !== undefined ? machineOEE[key] : 0,
    }));

    // Extract values and labels for the bar chart
    const oeeValues = fullOEEData.map(obj => obj.oee);
    const machineKeys = fullOEEData.map(obj => obj.machine);
    const customYTickLabels = machineKeys.map(label => label.toUpperCase());

    // Generate bar chart data
    const oeeBarData = [{
        x: oeeValues, // OEE values
        y: machineKeys, // Machine keys
        type: 'bar',
        orientation: 'h',
        marker: {
            color: oeeValues.map(value =>
                value >= 70 ? '#80c783' : value >= 30 ? '#ffd966' : '#f4a2a1'
            ), // Color based on OEE thresholds
        },
        text: oeeValues.map(value => `${value}%`), // Display OEE values as text
        textposition: 'inside',
        hoverinfo: "text",
        name: "OEE (%)",
    }];

    // Define layout
    const layout = {
        title: { text: "", x: 0.5 }, // Remove title to save space
        xaxis: {
            title: {
                text: "OEE (%)",
                font: { size: 12 }, // Adjust font size if needed
                standoff: 10, // Add spacing between axis and title
            },
            range: [0, 100],
            titlefont: { size: 14 },
            side: "bottom",
            tickangle: 0,
            automargin: true,
            titleposition: "start", // Left-align the title
        },
        yaxis: {
            tickvals: machineKeys, // Use original keys for tick positions
            ticktext: customYTickLabels, // Use custom labels for ticks
            automargin: true, // Dynamically adjust margins for long labels
            title: null, // Remove Y-axis title
        },
        margin: { t: 10, b: 30, l: 10, r: 20 }, // Adjust margins to give space for the bottom X-axis title
        height: container.offsetHeight, // Dynamically match container height
        width: container.offsetWidth, // Dynamically match container width
        showlegend: false,
    };

    return { data: oeeBarData, layout: layout };
}

function updateDailyOEEGauge(lineData, timeRange, gaugeContainer, isToday) {
    // Recalculate the OEE using the selected time range

    const { lineWholeDayOEE } = calculateLineOEE(lineData, false, timeRange, isToday);

    // Update the gauge plot
    generateGaugePlot(gaugeContainer, "Daily OEE", lineWholeDayOEE);
}

function initializeTimeSlider(sliderElement, line, isToday, lineData, gaugeContainer) {
    const currentHour = new Date().getHours(); // Current hour if today
    const currentEndTime = isToday ? Math.min(currentHour + 1, 24) : 24; // End time for today or default to 24
    const defaultStartTime = 7; // Default start time is 07:00 (TimeID = 8)

    if (sliderElement.noUiSlider) {
        // Slider already initialized; update options if necessary
        sliderElement.noUiSlider.updateOptions({
            start: [defaultStartTime, currentEndTime], // Default range starts at 07:00
        });
        return;
    }

    // Create the slider if not already initialized
    noUiSlider.create(sliderElement, {
        start: [defaultStartTime, currentEndTime], // Default range starts at 07:00
        connect: true,
        range: {
            min: 0,
            max: 24,
        },
        step: 1,
        tooltips: false,
        format: {
            to: value => Math.floor(value),
            from: value => parseInt(value, 10),
        },
    });

    // Update the time range display dynamically
    sliderElement.noUiSlider.on('update', function (values) {
        const start = Math.floor(values[0]);
        const end = Math.floor(values[1]);
        const timeRangeDisplay = document.getElementById(`time-range-display-${line}`);
        if (timeRangeDisplay) {
            timeRangeDisplay.textContent = `${String(start).padStart(2, '0')}:00 - ${String(end).padStart(2, '0')}:00`;
        }
    });

    // Update Daily OEE when the slider value changes
    sliderElement.noUiSlider.on('change', function () {
        const { startTimeID, endTimeID } = getSliderTimeRange(sliderElement, isToday, currentHour);
        const timeRange = { startTimeID, endTimeID };
        updateDailyOEEGauge(lineData, timeRange, gaugeContainer, isToday);
    });
}

function getSliderTimeRange(sliderElement) {
    // Get the current values from the slider
    const [start, end] = sliderElement.noUiSlider.get().map(value => Math.floor(value));

    // Convert the slider values to time format (e.g., "00:00", "23:00")
    const startTime = `${String(start).padStart(2, '0')}:00`;
    const endTime = `${String(end).padStart(2, '0')}:00`;

    return { startTime, endTime, startTimeID: start + 1, endTimeID: end }; // Include TimeID if needed
}

function createFlipCard(lineData, oeeLineData) {
    const flipCard = document.createElement("div");
    flipCard.classList.add("flip-card");
    flipCard.style.width = "100%"; // Ensure it respects grid width
    flipCard.style.height = "250px"; // Fixed height to match design

    const flipCardInner = document.createElement("div");
    flipCardInner.classList.add("flip-card-inner");

    const front = document.createElement("div");
    front.classList.add("front");

    const back = document.createElement("div");
    back.classList.add("back");

    const barContainer = document.createElement("div");
    barContainer.classList.add("plot-container");
    barContainer.style.width = "100%"; // Ensure the plot respects the flip card width
    barContainer.style.height = "100%"; // Ensure the plot respects the flip card height
    front.appendChild(barContainer);

    const oeeBarContainer = document.createElement("div");
    oeeBarContainer.classList.add("plot-container");
    oeeBarContainer.style.width = "100%";
    oeeBarContainer.style.height = "100%";
    back.appendChild(oeeBarContainer);

    flipCardInner.appendChild(front);
    flipCardInner.appendChild(back);
    flipCard.appendChild(flipCardInner);

    // Add click event listener to toggle the "flipped" class
    flipCard.addEventListener("click", () => {
        flipCard.classList.toggle("flipped");
    });

    // Generate plots for the flip card
    const barPlotData = generateBarPlotData(lineData, barContainer); // Pass barContainer
    const oeePlotData = generateOEEPlotData(oeeLineData, oeeBarContainer); // Pass oeeBarContainer

    Plotly.newPlot(barContainer, barPlotData.data, barPlotData.layout, { responsive: true });
    Plotly.newPlot(oeeBarContainer, oeePlotData.data, oeePlotData.layout, { responsive: true });

    return flipCard;
}

function generateGaugePlot(container, title, value) {
    const generateGaugeData = (value) => ({
        type: "indicator",
        mode: "gauge+number",
        value: parseFloat(value.toFixed(2)), // Ensure the value itself is formatted to 2 decimal places
        number: {
            font: { 
                size: container.offsetWidth * 0.08, // Scale font size dynamically
                color: value < 30 ? "#ff7f7f" : value < 70 ? "#ffdd57" : "#4da3ff"
            },
            suffix: "%", // Adds percentage symbol to the value
            valueformat: ".2f" // Format the number to 2 decimal 
        },
        gauge: {
            axis: { range: [0, 100], tickwidth: 1, tickcolor: "darkgray" },
            bar: { color: value < 30 ? "#ff7f7f" : value < 70 ? "#ffdd57" : "#4da3ff" },
            steps: [
                { range: [0, 30], color: "#ffe6e6" },
                { range: [30, 70], color: "#fff8c4" },
                { range: [70, 100], color: "#d2e9ff" },
            ],
        },
    });    

    const generateGaugeLayout = (titleText) => ({
        margin: { t: 0, b: 0, l: 45, r: 45 }, // Compact margins
        width: container.offsetWidth, // Automatically adjust to parent width
        height: container.offsetHeight* 0.95, // Automatically adjust to parent height
        font: { color: "#4a4a4a", family: "Arial",  size: container.offsetHeight * 0.06},
        annotations: [
            {
                x: 0.5, // Center horizontally
                y: 0.5, // Position above the value
                text: `<b>${titleText}</b>`, // Bold title text
                showarrow: false,
                font: { 
                    size: container.offsetHeight * 0.05, // Dynamically adjust title size
                    color: "gray" 
                },
                align: "center",
            },
        ],
    });

    const animateGauge = (container, value, layout) => {
        if (value === 0) {
            // Directly render the gauge with 0 value
            const data = [generateGaugeData(0)];
            Plotly.react(container, data, layout, { responsive: true });
            return;
        }
    
        let currentValue = 0;
        const totalFrames = 20; // Total frames for smoother animation
        const increment = value / totalFrames;
    
        const step = () => {
            if (currentValue < value) {
                currentValue = Math.min(currentValue + increment, value); // Increment value
                const data = [generateGaugeData(currentValue)];
                Plotly.react(container, data, layout, { responsive: true });
                requestAnimationFrame(step); // Use requestAnimationFrame for smoother rendering
            }
        };
    
        step(); // Start the animation
    };
    

    // Animate Current OEE Gauge
    animateGauge(
        container,
        value,
        generateGaugeLayout(title),
    );
    
}

function generateBarPlotData(lineData, container) {
    const orderedMachines = ['powerfan', 'dimm1', 'dimm2', 'dimm3', 'aoi'];
    const displayLabels = orderedMachines.map(machine => machine.toUpperCase());
  
    const barData = [];
    const annotations = [];
    let maxTotalTime = 0;
  
    const legendTracker = new Set();
  
    const addBarData = (name, color, value, label) => {
        const showLegend = !legendTracker.has(name);
        legendTracker.add(name);

        barData.push({
        x: [label],
        y: [value],
        name: name,
        type: "bar",
        marker: { color: color },
        text: value > 0 ? `${Math.floor(value / 60)}m ${value % 60}s` : "0",
        textposition: "inside",
        hoverinfo: value > 0 ? "text" : "skip",
        legendgroup: name,
        showlegend: showLegend,
        });
    };
  
    orderedMachines.forEach((machine, index) => {
        const machineData = lineData.find(row => row.machine === machine);
        const label = displayLabels[index];

        if (machineData) {
        const { RunTime, StandByTime, ErrorTime, StopTime, Yield } = machineData;
        const effectiveTime = RunTime + StandByTime + ErrorTime + StopTime;

        maxTotalTime = Math.max(maxTotalTime, effectiveTime);

        addBarData("Run", "#58D68D", RunTime, label);
        addBarData("StandBy", "#F7DC6F", StandByTime, label);
        addBarData("Error", "#EC7063", ErrorTime, label);
        addBarData("Stop", "#AAB7B8", StopTime, label);

        annotations.push({
            x: label,
            y: effectiveTime + 90,
            text: `Yield: ${Math.round(Yield)}`,
            showarrow: false,
        });
        } else {
        addBarData("Run", "#58D68D", 0, label);
        addBarData("StandBy", "#F7DC6F", 0, label);
        addBarData("Error", "#EC7063", 0, label);
        addBarData("Stop", "#AAB7B8", 0, label);
        }
    });
  
    const layout = {
        barmode: "stack",
        yaxis: { title: "Time (seconds)", range: [0, maxTotalTime + 400], automargin: true },
        xaxis: { tickvals: displayLabels, ticktext: displayLabels },
        legend: {
            orientation: "h", // Horizontal legend
            x: 0.5, // Center the legend
            y: 1.15, // Place legend above the plot
            xanchor: "center", // Center alignment
            yanchor: "top", // Align to the top
            font: { size: 12 }, // Reduce legend font size
            itemwidth: 0, // Adjust spacing for each legend item
        },
        annotations: annotations,
        margin: { t: 10, b: 10, l: 30, r: 10 }, // Reduce margins
        height: container.offsetHeight, // Dynamically match container height
        width: container.offsetWidth, // Dynamically match container width
    };
  
    return { data: barData, layout: layout };
}

// Function to format duration
function formatDuration(seconds) {
    if (seconds < 0) return '0s'; // Handle invalid input

    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = (seconds % 60).toFixed(2); // Round to 2 decimal places

    return [
        hrs > 0 ? `${hrs}h` : '',
        mins > 0 ? `${mins}m` : '',
        `${secs}s`,
    ]
        .filter(Boolean)
        .join(' ');
}

// Reset grid layout
function resetGridLayout() {
    const plotsContainer = document.getElementById("plots-container");
    
    // Clear all child nodes
    while (plotsContainer.firstChild) {
        plotsContainer.removeChild(plotsContainer.firstChild);
    }

    // Reset container class and styles
    plotsContainer.className = ""; // Clear all classes
    plotsContainer.style = ""; // Clear inline styles
    plotsContainer.classList.add("dashboard-grid"); // Reapply grid class
}

function resizePlots() {
    const gaugeContainers = document.querySelectorAll(".gauge-container > div");
    gaugeContainers.forEach((container) => {
        Plotly.Plots.resize(container); // Trigger Plotly to adjust the plot size
    });
    const plotContainers = document.querySelectorAll(".plot-container");
    plotContainers.forEach((container) => {
        Plotly.Plots.resize(container); // Resize each plot
    });
}

function redirectToLineDetails() {
    const selectedLine = document.getElementById("line-dropdown").value;

    if (selectedLine === "all") {
        alert("Please select a specific line to view details.");
        return;
    }

    // Redirect to the new page with the selected line
    window.location.href = `/line-detail/${selectedLine}/`;
}

function showLoadingScreen() {
    const loadingScreen = document.querySelector("#plots-container .loading-screen");
    const plotsContainer = document.getElementById("plots-container");

    if (loadingScreen && plotsContainer) {
        loadingScreen.classList.remove("hidden"); // Show the loading screen
    }
}

function hideLoadingScreen() {
    const loadingScreen = document.querySelector("#plots-container .loading-screen");
    const plotsContainer = document.getElementById("plots-container");

    if (loadingScreen && plotsContainer) {
        loadingScreen.classList.add("hidden"); // Hide the loading screen
    }
}



