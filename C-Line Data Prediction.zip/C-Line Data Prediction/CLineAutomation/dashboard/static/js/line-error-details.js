let currentLineName = "";
let currentData = []; // Global variable to store data

export function initializeErrorTab(data, lineName) {
    // Set the current line name globally
    currentLineName = lineName;

    // Store the data globally, even if empty
    currentData = data || [];

    // Set default filters
    setDefaultFilters();
    populateErrorDefDropdown(currentData);
    attachApplyFiltersListener();
    attachErrorDefFilterListener();
    // Populate the default view (Summary Table) if data exists
    if (currentData.length > 0) {
        populateRecentErrorsTable(currentData);
    } else {
        document.getElementById("error-content").innerHTML = `
        <p style="text-align: center; color: red; font-size: 18px;">
            No Error Data Found. Please try adjusting filters or selecting another time range.
        </p>`;
    }

    // Attach listeners for tab switching and filters
    attachSubTabListener();
}

function attachSubTabListener() {
    const subTabs = document.querySelectorAll(".error-sub-tabs .sub-tab");

    subTabs.forEach((tab) => {
        tab.addEventListener("click", (event) => {
            // Remove 'active' class from all sub-tabs
            subTabs.forEach((t) => t.classList.remove("active"));

            // Add 'active' class to the clicked sub-tab
            event.target.classList.add("active");

            // Capture the data-sub-tab attribute
            const activeSubTab = event.target.dataset.subTab;

            // Update the active tab content
            updateActiveTabContent(activeSubTab);
        });
    });
}

function getActiveSubTab() {
    // Find the active sub-tab under the `.error-sub-tabs` container
    const activeSubTabElement = document.querySelector(".error-sub-tabs .sub-tab.active");
    const activeSubTab = activeSubTabElement.dataset.subTab;
    return activeSubTab;
}

function attachApplyFiltersListener() {
    const filterInputs = [
        document.getElementById("start_date"),
        document.getElementById("end_date"),
        document.getElementById("start_time"),
        document.getElementById("end_time"),
    ];

    filterInputs.forEach(input => {
        if (input) {
            input.addEventListener("change", () => {
                const startDate = document.getElementById("start_date").value;
                const endDate = document.getElementById("end_date").value;
                const startTime = document.getElementById("start_time").value;
                const endTime = document.getElementById("end_time").value;

                // Get the active sub-tab
                const activeSubTab = getActiveSubTab();

                // Fetch data based on the selected filters
                fetchFilteredData(currentLineName, startDate, endDate, startTime, endTime, activeSubTab);
            });
        }
    });
}

function fetchFilteredData(lineName, startDate, endDate, startTime, endTime, activeSubTab) {
    showErrorLoadingScreen(); // Show the loading circle
    const params = new URLSearchParams({
        start_date: startDate || "",
        end_date: endDate || "",
        start_time: startTime || "",
        end_time: endTime || "",
    });

    fetch(`/line/${lineName}/error-data/?${params.toString()}`)
        .then((response) => {
            if (!response.ok) throw new Error("Failed to fetch filtered error data.");
            return response.json();
        })
        .then((data) => {
            currentData = data.filtered_data || []; // Update global data

            // Update the dropdown with new error definitions
            populateErrorDefDropdown(currentData);

            // Attach listeners to the updated dropdown
            attachErrorDefFilterListener();

            // Update the active tab content with the filtered data
            updateActiveTabContent(activeSubTab);
        })
        .catch((error) => {
            console.error("Error fetching filtered data:", error);
            currentData = []; // Reset data on error
            populateErrorDefDropdown([]); // Clear the dropdown
            updateActiveTabContent(activeSubTab); // Clear content
        })
        .finally(() => {
            hideErrorLoadingScreen(); // Hide the loading circle
        });
}

function updateActiveTabContent(activeSubTab) {
    // Hide all sub-tab content sections
    const subTabContents = document.querySelectorAll(".sub-tab-content");
    subTabContents.forEach((content) => {
        content.classList.remove("active");
        content.style.display = "none"; // Hide all content
    });

    // Show the content for the active tab
    const activeContent = document.getElementById(activeSubTab);
    if (activeContent) {
        activeContent.classList.add("active");
        activeContent.style.display = "block";

        // Populate content dynamically based on the tab
        if (activeSubTab === "summary-table") {
            populateRecentErrorsTable(currentData); // Populate table
        } else if (activeSubTab === "error-plot") {
            plotDetailedChart(currentData); // Populate plot
        }
    }
}

function setDefaultFilters() {
    const today = new Date().toISOString().slice(0, 10); // YYYY-MM-DD format
    document.getElementById("start_date").value = today;
    document.getElementById("end_date").value = today;
    document.getElementById("start_time").value = "00:00";
    document.getElementById("end_time").value = "23:59";
}

function populateErrorDefDropdown(data) {
    const errorDefContainer = document.getElementById("error_def");
    errorDefContainer.innerHTML = ""; // Clear existing checkboxes

    // Extract unique error definitions from the data
    const uniqueErrorDefs = [...new Set(data.map(item => item.Error_Def))];

    // Create checkboxes for each error type
    uniqueErrorDefs.forEach(def => {
        const checkbox = document.createElement("input");
        checkbox.type = "checkbox";
        checkbox.value = def;
        checkbox.checked = true; // Default all to checked
        checkbox.className = "error-checkbox";

        const label = document.createElement("label");
        label.textContent = def;
        label.prepend(checkbox);

        errorDefContainer.appendChild(label);
    });
    console.log("here")
    // Attach "Select All" functionality
    attachSelectAllListener();
}


function attachSelectAllListener() {
    const errorDefContainer = document.getElementById("error_def");

    // Remove existing "Select All" if it already exists to avoid duplicates
    const existingSelectAll = document.getElementById("select_all");
    if (existingSelectAll) {
        existingSelectAll.parentElement.remove();
    }

    // Create "Select All" checkbox dynamically
    const selectAllLabel = document.createElement("label");
    const selectAllCheckbox = document.createElement("input");
    selectAllCheckbox.type = "checkbox";
    selectAllCheckbox.id = "select_all";
    selectAllCheckbox.checked = true; // Default "Select All" to checked
    selectAllLabel.appendChild(selectAllCheckbox);
    selectAllLabel.appendChild(document.createTextNode("Select All"));

    // Add the "Select All" checkbox to the top of the container
    errorDefContainer.insertBefore(selectAllLabel, errorDefContainer.firstChild);

    // Get all error checkboxes
    const errorCheckboxes = document.querySelectorAll(".error-checkbox");

    // Add "Select All" functionality
    selectAllCheckbox.addEventListener("change", () => {
        const isChecked = selectAllCheckbox.checked;
        errorCheckboxes.forEach(checkbox => {
            checkbox.checked = isChecked;
        });
        filterDataByErrorDef(); // Apply filter when "Select All" is toggled
    });

    // Add listeners to individual checkboxes to update "Select All" state
    errorCheckboxes.forEach(checkbox => {
        checkbox.addEventListener("change", () => {
            const allChecked = [...errorCheckboxes].every(cb => cb.checked);
            selectAllCheckbox.checked = allChecked; // Update "Select All" state
            filterDataByErrorDef(); // Apply filter when any checkbox changes
        });
    });
}

function filterDataByErrorDef() {
    const selectedErrorDefs = Array.from(document.querySelectorAll(".error-checkbox:checked")).map(cb => cb.value);

    if (selectedErrorDefs.length === 0) {
        // Show a message if no checkboxes are selected
        document.getElementById("recent-errors-table").innerHTML = `
            <p style="text-align: center; color: red; font-size: 18px;">
                No Error Types Selected. Please select at least one.
            </p>`;
        return;
    }

    // Filter currentData to include only rows with selected Error_Def values
    const filteredData = currentData.filter(item => selectedErrorDefs.includes(item.Error_Def));

    // Update the displayed data
    populateRecentErrorsTable(filteredData);
    plotDetailedChart(filteredData);
}

function attachErrorDefFilterListener() {
    const errorCheckboxes = document.querySelectorAll(".error-checkbox");
    errorCheckboxes.forEach(checkbox => {
        checkbox.removeEventListener("change", filterDataByErrorDef); // Prevent duplicate listeners
        checkbox.addEventListener("change", filterDataByErrorDef);
    });
}

function formatDuration(seconds) {
    if (seconds < 0) return '0s'; // Handle invalid input

    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = (seconds % 60).toFixed(2); // Round to 2 decimal places

    return [
        hrs > 0 ? `${hrs}h` : '',
        mins > 0 ? `${mins}m` : '',
        `${secs}s`,
    ]
        .filter(Boolean)
        .join(' ');
}

function populateRecentErrorsTable(detailData) {
    const machines = [...new Set(detailData.map(row => row.machine))];
    const recentErrorsTable = document.getElementById("recent-errors-table");
    recentErrorsTable.innerHTML = ""; // Clear existing content
    const errorContent = document.getElementById("error-content")
    if (!detailData || detailData.length === 0) {
        // Display error message when no data is available
        recentErrorsTable.innerHTML = `
            <p style="text-align: center; color: red; font-size: 18px;">
                No Error Data Found. Please try adjusting filters or selecting another time range.
            </p>`;
        return;
    }

    // Create table structure
    const table = document.createElement("table");
    table.classList.add("error-table"); // Add CSS class for styling

    // Header Row
    const headerRow = table.insertRow();
    headerRow.insertCell().outerHTML = `<th rowspan="2">Machine</th>`; // MACHINE column
    for (let i = 1; i <= 3; i++) {
        const cell = headerRow.insertCell();
        cell.colSpan = 3;
        cell.textContent = `Record ${i}`;
    }
    const longestCell = headerRow.insertCell();
    longestCell.colSpan = 3;
    longestCell.textContent = "Longest Error";

    // Sub-header Row for fields: Error, Error Time, Duration
    const subHeaderRow = table.insertRow();
    for (let i = 0; i < 4; i++) {
        ["Error", "Error Time", "Duration"].forEach(text => {
            const cell = document.createElement("th");
            cell.textContent = text;
            subHeaderRow.appendChild(cell);
        });
    }


    // Function to format Error Time with StartDate
    const formatErrorTime = (start, end) => {
        const startDate = start.split("T")[0]; // Extract date from StartDateTime
        const startTime = start.split("T")[1].split(".")[0]; // Extract time
        const endTime = end.split("T")[1].split(".")[0];     // Extract time

        // Display StartDate on the first line, Start-End time on the second line
        return `${startDate}<br>${startTime}-${endTime}`;
    };

    // Function to get 3 most recent records
    const getRecentErrors = (machine) => {
        return detailData
            .filter(row => row.machine === machine)
            .sort((a, b) => new Date(b.StartDateTime) - new Date(a.StartDateTime))
            .slice(0, 3); // Top 3 recent errors
    };

    // Function to get the longest error
    const getLongestError = (machine) => {
        return detailData
            .filter(row => row.machine === machine)
            .reduce((longest, current) => (current.Duration > (longest.Duration || 0) ? current : longest), {});
    };

    // Add rows for each machine
    machines.forEach((machine) => {
        const row = table.insertRow();

        // Insert MACHINE column
        const machineCell = row.insertCell();
        machineCell.textContent = machine;
        machineCell.style.fontWeight = "bold";

        // Get recent errors and longest error
        const recentErrors = getRecentErrors(machine);
        const longestError = getLongestError(machine);

        // Add 3 recent errors
        for (let i = 0; i < 3; i++) {
            const error = recentErrors[i] || {}; // Fetch record or empty object
            const formattedErrorTime = error.StartDateTime && error.EndDateTime
                ? formatErrorTime(error.StartDateTime, error.EndDateTime)
                : "-";
            const formattedDuration = error.Duration !== undefined
                ? formatDuration(error.Duration)
                : "-";

            const splitErrorDef = (error.Error_Def || "-").split("/");
            const formattedErrorDef = splitErrorDef.length > 1
                ? `${splitErrorDef[0]}<br>${splitErrorDef[1]}`
                : splitErrorDef[0];

            [formattedErrorDef, formattedErrorTime, formattedDuration].forEach(value => {
                const cell = row.insertCell();
                cell.innerHTML = value;
            });
        }

        // Add longest error
        const longestErrorTime = longestError.StartDateTime && longestError.EndDateTime
            ? formatErrorTime(longestError.StartDateTime, longestError.EndDateTime)
            : "-";
        const longestDuration = longestError.Duration !== undefined
            ? formatDuration(longestError.Duration)
            : "-";

        const splitLongestErrorDef = (longestError.Error_Def || "-").split("/");
        const formattedLongestErrorDef = splitLongestErrorDef.length > 1
            ? `${splitLongestErrorDef[0]}<br>${splitLongestErrorDef[1]}`
            : splitLongestErrorDef[0];

        [formattedLongestErrorDef, longestErrorTime, longestDuration].forEach(value => {
            const cell = row.insertCell();
            cell.innerHTML = value;
            cell.style.backgroundColor = "#ffebcc"; // Highlight for longest error
        });
    });

    recentErrorsTable.appendChild(table);
}

function plotDetailedChart(detailData) {
    const detailContainer = document.getElementById("detailed-container");
    detailContainer.innerHTML = ""; // Clear existing content
    const errorContent = document.getElementById("error-content")
    if (!detailData || detailData.length === 0) {
        // Display error message when no data is available
        detailContainer.innerHTML = `
            <p style="text-align: center; color: red; font-size: 18px;">
                No Error Data Found. Please try adjusting filters or selecting another time range.
            </p>`;
        return;
    }
    const machines = [...new Set(detailData.map(row => row.machine))];
    const errorDefs = [...new Set(detailData.map(row => row.Error_Def))];

    // Calculate total counts and sort error definitions by total counts
    const totalCounts = errorDefs.map(errorDef => {
        const total = detailData.filter(row => row.Error_Def === errorDef).length;
        return { errorDef, total };
    });

    totalCounts.sort((a, b) => b.total - a.total);
    const sortedErrorDefs = totalCounts.map(item => item.errorDef);

    // Wrap long error definitions for x-axis labels and split Chinese/English
    const wrappedErrorDefs = sortedErrorDefs.map(errorDef => {
        const [chinese, english] = errorDef.split('/');
        return `${chinese || ''}<br>${english || ''}`.trim();
    });

    // Create grouped bar chart data
    const barData = machines.map(machine => {
        const counts = sortedErrorDefs.map(errorDef => {
            return detailData.filter(row => row.machine === machine && row.Error_Def === errorDef).length || 0;
        });

        const hoverTexts = sortedErrorDefs.map((errorDef, i) => {
            // Split Error Definition into English and Chinese
            const [chineseDef, englishDef] = errorDef.split('/');
            const errorDefHeader = `Error English Definition: ${englishDef || 'N/A'}<br>Error Chinese Definition: ${chineseDef || 'N/A'}`;

            // Filter rows for the current machine and error definition
            const matchingRows = detailData.filter(
                row => row.machine === machine && row.Error_Def === errorDef
            );

            if (matchingRows.length === 0) return null; // Skip if no data for this machine and error

            const machineCounts = matchingRows.length;
            const machineDuration = matchingRows.reduce((sum, r) => sum + r.Duration, 0);
            const machineAvgDuration = machineDuration / machineCounts || 0;

            // Logic for total counts less than 20
            if (machineCounts < 20) {
                const details = matchingRows
                    .map(
                        r =>
                            `Start Time: ${r.StartDateTime.replace(
                                "T",
                                "-"
                            )}; Duration: ${formatDuration(r.Duration)}`
                    )
                    .join('<br>');

                return `Machine: ${machine}<br>${errorDefHeader}<br>${details}<br>Average Duration: ${formatDuration(
                    machineAvgDuration
                )}`;
            }

            // Simplified hover for total counts >= 20
            return `Machine: ${machine}<br>${errorDefHeader}<br>Average Duration: ${formatDuration(
                machineAvgDuration
            )}<br>Counts: ${machineCounts} times`;
        });

        return {
            x: wrappedErrorDefs,
            y: counts,
            name: machine, // Machine legend
            type: 'bar',
            text: counts.map(count => `${count} times`),
            textposition: 'auto',
            hoverinfo: 'text',
            hovertext: hoverTexts,
        };
    });

    // Update layout to include dynamic height
    const layout = {
        title: {
            text: 'Error Types and Counts with Duration Details',
            font: { size: 16 },
            x: 0.5,
            xanchor: 'center',
        },
        barmode: 'group',
        hovermode: 'closest',
        height: 500,  // Set dynamic height
        width: 1200, // Dynamically calculated width
        legend: {
            orientation: 'h',
            y: 1.1,
            x: 0.5,
            xanchor: 'center',
        },
        xaxis: {
            title: { text: 'Error Types', standoff: 25 },
            tickangle: -45,
            tickfont: { size: 10 },
            automargin: true,
        },
        yaxis: {
            title: 'Counts',
            tickformat: ',d',
        },
        margin: { l: 60, r: 10, t: 80, b: 80 },
        autosize: true,
    };


    // Render the chart
    Plotly.newPlot(detailContainer, barData, layout);
    window.dispatchEvent(new Event('resize'));
}

export function showErrorLoadingScreen() {
    const loadingScreen = document.querySelector("#error-content #loading-screen");
    const summaryTable = document.getElementById("summary-table");
    const errorPlot = document.getElementById("error-plot");

    if (loadingScreen) {
        console.log("Showing loading screen...");
        loadingScreen.classList.remove("hidden"); // Show loading screen
    }

    // Hide the table and chart
    if (summaryTable) {
        summaryTable.style.visibility = "hidden"; // Keep layout intact but hide content
    }
    if (errorPlot) {
        errorPlot.style.visibility = "hidden";
    }
}

export function hideErrorLoadingScreen() {
    const loadingScreen = document.querySelector("#error-content #loading-screen");
    const summaryTable = document.getElementById("summary-table");
    const errorPlot = document.getElementById("error-plot");

    if (loadingScreen) {
        console.log("Hiding loading screen...");
        loadingScreen.classList.add("hidden"); // Hide loading screen
    }

    // Show the table and chart
    if (summaryTable) {
        summaryTable.style.visibility = "visible"; // Make content visible again
    }
    if (errorPlot) {
        errorPlot.style.visibility = "visible";
    }
}


