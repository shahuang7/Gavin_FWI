import { initializeYieldTab } from "./line-yield-details.js";
import { initializePressureTab, showPressureLoadingScreen, hidePressureLoadingScreen } from "./line-pressure-details.js";
import { initializeErrorTab, showErrorLoadingScreen, hideErrorLoadingScreen } from "./line-error-details.js";

document.addEventListener("DOMContentLoaded", function () {
    const tabs = document.querySelectorAll(".tab");
    const contents = document.querySelectorAll(".tab-content");

    // Event listener for tab clicks
    tabs.forEach(tab => {
        tab.addEventListener("click", function () {
            // Clear active classes
            tabs.forEach(t => t.classList.remove("active"));
            contents.forEach(c => c.classList.remove("active"));

            // Activate the selected tab
            this.classList.add("active");
            const tabId = this.getAttribute("data-tab");
            const tabContent = document.getElementById(tabId);

            if (tabContent) {
                tabContent.classList.add("active");
            }

            const lineName = this.getAttribute("data-line-name");
            if (!lineName) {
                console.error(`data-line-name attribute missing for ${tabId} tab.`);
                return;
            }

            // Handle Yield Tab
            if (tabId === "yield") {
                initializeYieldTab(lineName);
            }

            // Handle Pressure Tab
            if (tabId === "pressure") {
                fetchAndDisplayPressureData(lineName, "DIMM1"); // Default to DIMM1
            }

            // Handle Error Tab
            if (tabId === "error") {
                fetchAndDisplayErrorData(lineName);
            }
        });
    });

    // Trigger initialization for the default active tab
    const defaultTab = document.querySelector(".tab.active");
    if (defaultTab) {
        const tabId = defaultTab.getAttribute("data-tab");
        const lineName = defaultTab.getAttribute("data-line-name");
        if (tabId === "yield") {
            initializeYieldTab(lineName);
        } else if (tabId === "pressure") {
            fetchAndDisplayPressureData(lineName, "DIMM1"); // Default to DIMM1
        }
    }

    // Function to fetch pressure data
    function fetchAndDisplayPressureData(lineName, machine) {
        const today = new Date().toLocaleDateString("en-CA"); // Format today's date in ISO format
        const params = new URLSearchParams({
            date: today,
            machine: machine,
        });
    
        // Show the loading screen
        showPressureLoadingScreen();
    
        fetch(`/line/${lineName}/pressure-data/?${params.toString()}`)
            .then(response => {
                if (!response.ok) throw new Error("Failed to fetch pressure data.");
                return response.json();
            })
            .then(data => {
                if (data.filtered_data) {
                    // Initialize the Pressure Tab with the filtered data
                    initializePressureTab(lineName, {
                        filtered_data: data.filtered_data, // Full dataset for the selected machine and date
                    });
                } else {
                    console.warn("No pressure data returned from the server.");
                }
            })
            .catch(error => {
                console.error("Error fetching pressure data:", error);
            })
            .finally(() => {
                // Hide the loading screen after fetch completes, whether successful or not
                hidePressureLoadingScreen();
            });
    }    

    // Function to fetch error data
    function fetchAndDisplayErrorData(lineName) {
        const today = new Date().toLocaleDateString("en-CA");
        const params = new URLSearchParams({
            start_date: today,
            end_date: today,
        });
    
        // Show the loading screen immediately
        showErrorLoadingScreen();
    
        fetch(`/line/${lineName}/error-data/?${params.toString()}`)
            .then(response => {
                if (!response.ok) throw new Error("Failed to fetch error data.");
                return response.json();
            })
            .then(data => {
                console.log("Error data fetched successfully:", data);
                initializeErrorTab(data.filtered_data || [], lineName); // Pass both data and lineName
            })
            .catch(error => {
                console.error("Error fetching error data:", error);
                initializeErrorTab([], lineName); // Ensure initializeErrorTab is called even on error
            })
            .finally(() => {
                // Hide the loading screen after fetch completes, whether successful or not
                hideErrorLoadingScreen();
            });
    }    
});


document.getElementById("line-search-button").addEventListener("click", () => {
    const selectedLine = document.getElementById("line-selector").value;

    if (selectedLine) {
        // Replace the current line in the URL with the selected one
        const currentURL = window.location.href; // e.g., http://127.0.0.1:5566/line-detail/C2/
        const baseURL = currentURL.split("/line-detail/")[0]; // Extract base URL
        const newURL = `${baseURL}/line-detail/${selectedLine}/`; // New URL for the selected line

        window.location.href = newURL; // Redirect to the new URL
    } else {
        alert("Please select a line to navigate.");
    }
});

document.getElementById("homepage-button").addEventListener("click", () => {
    window.location.href = "/"; // Redirect to the homepage
});

// Function to format duration
export function formatDuration(seconds) {
    if (seconds < 0) return '0s'; // Handle invalid input

    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = (seconds % 60).toFixed(2); // Round to 2 decimal places

    return [
        hrs > 0 ? `${hrs}h` : '',
        mins > 0 ? `${mins}m` : '',
        `${secs}s`,
    ]
        .filter(Boolean)
        .join(' ');
}

// // Function to check for new errors
// async function checkForNewErrors() {
//     try {
//         const response = await fetch('/check-new-errors/'); // Ensure this matches your backend URL
//         const data = await response.json();

//         if (data.new_errors) {
//             const newErrors = data.new_data; // Array of new error rows

//             // Construct an aggregated message
//             let aggregatedMessage = "New Errors Detected:\n";
//             newErrors.forEach((error, index) => {
//                 const duration = formatDuration(error.Duration); // Format the duration
//                 const startDateTime = error.StartDateTime.replace("T", " "); // Replace T with space
//                 const endDateTime = error.EndDateTime.replace("T", " "); // Replace T with space
//                 aggregatedMessage += `
//                                     ${index + 1}. ${error["line-machine"]} had error "${error.Error_Def}" 
//                                         from ${startDateTime} to ${endDateTime}, 
//                                         taking ${duration} to resolve.
//                                     `;
//             });

//             console.log("Get New Errors", aggregatedMessage);
//             alert(aggregatedMessage.trim()); // Display the aggregated message
//         }
//     } catch (error) {
//         console.error("Error checking for new rows:", error);
//     }
// }

// // Poll the backend every minute
// setInterval(checkForNewErrors, 60000); // 1 minute

