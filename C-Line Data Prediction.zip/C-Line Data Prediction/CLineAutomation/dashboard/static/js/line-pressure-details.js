let currentLineName = ""; 
let currentData = []; // Store pressure data globally
let currentMachine = "DIMM1";
let currentDate = new Date().toLocaleDateString("en-CA");
let currentProductSN = null;

/**
 * Initialize the Pressure Tab during the first load.
 */
export function initializePressureTab(lineName, initialData) {

    // Reset global state
    currentLineName = lineName;
    currentData = initialData.filtered_data;
    currentMachine = "DIMM1"; // Reset to default machine
    currentDate = new Date().toLocaleDateString("en-CA"); // Reset to today's date

    // Calculate unique ProductSNs and reverse the list
    const uniqueProductSNs = [...new Set(currentData.map(item => item.ProductSN))].reverse();
    currentProductSN = uniqueProductSNs[0]; // Last ProductSN in the data

    initializeDatePicker();
    initializeProductSNDropdown(uniqueProductSNs);
    attachPressureSubTabListeners();

    // Populate initial data filtered by the last ProductSN
    populatePressureData(currentData.filter(item => item.ProductSN === currentProductSN));

}

/**
 * Set the date picker to today's date by default.
 */
function initializeDatePicker() {
    const datePicker = document.getElementById("pressure-date");
    if (datePicker) {
        datePicker.value = currentDate;

        datePicker.addEventListener("change", () => {
            currentDate = datePicker.value;
            fetchAndUpdatePressureData(currentMachine, currentDate); // Re-fetch data when the date changes
        });
    }
}

/**
 * Initialize dropdown with unique ProductSN from the filtered data.
 */
function initializeProductSNDropdown(uniqueProductSNs) {
    const dropdownButton = document.getElementById("product-sn-button");
    const dropdownContent = document.getElementById("product-sn-filter");

    if (!dropdownButton || !dropdownContent) {
        console.error("ProductSN dropdown elements not found.");
        return;
    }

    // Clear existing options
    dropdownContent.innerHTML = "";

    // Populate dropdown options in reverse order
    uniqueProductSNs.forEach(sn => {
        const option = document.createElement("div");
        option.className = "dropdown-option";
        option.textContent = sn;
        option.dataset.sn = sn;

        option.addEventListener("click", () => {
            currentProductSN = sn;
            dropdownButton.textContent = sn; // Update button text
            populatePressureData(currentData.filter(item => item.ProductSN === currentProductSN)); // Filter data by selected ProductSN
        });

        dropdownContent.appendChild(option);
    });

    // Set default dropdown text
    dropdownButton.textContent = currentProductSN || "Select ProductSN";
}

/**
 * Attach event listeners to sub-tabs for machine filtering.
 */
function attachPressureSubTabListeners() {
    const subTabs = document.querySelectorAll(".sub-tab");

    // Set the 'active' class for the default machine sub-tab (DIMM1)
    const defaultSubTab = Array.from(subTabs).find(tab => tab.getAttribute("data-machine") === "DIMM1");
    if (defaultSubTab) {
        defaultSubTab.classList.add("active");
    }

    subTabs.forEach(tab => {
        tab.addEventListener("click", function () {
            // Remove 'active' class from all tabs
            subTabs.forEach(t => t.classList.remove("active"));
            this.classList.add("active");

            // Fetch new data based on the selected machine
            currentMachine = this.getAttribute("data-machine");

            fetchAndUpdatePressureData(currentMachine, currentDate);
        });
    });
}


/**
 * Fetch and update pressure data dynamically.
 */
function fetchAndUpdatePressureData(machine, date) {
    const params = new URLSearchParams({
        date: date,
        machine: machine,
    });
    const plotContainer = document.getElementById("pressure-plot-container");
    showPressureLoadingScreen(); // Show loading screen before fetching

    fetch(`/line/${currentLineName}/pressure-data/?${params.toString()}`)
        .then(response => {
            if (!response.ok) {
                populatePressureData([]); // Populate with empty data
                throw new Error(`HTTP error! Status: ${response.status}`); // Throw error to skip remaining .then
            }
            return response.json();
        })
        .then(data => {
            if (data.filtered_data) {
                currentData = data.filtered_data;

                // Recalculate unique ProductSNs and reinitialize dropdown
                const uniqueProductSNs = [...new Set(currentData.map(item => item.ProductSN))].reverse();
                currentProductSN = uniqueProductSNs[0]; // Last ProductSN
                initializeProductSNDropdown(uniqueProductSNs);
                populatePressureData(currentData.filter(item => item.ProductSN === currentProductSN)); // Filter data by the last ProductSN
            } else {
                console.warn("No data returned for the selected filters.");
            }
        })
        .catch(error => {
            console.error("Error fetching pressure data:", error);
        })
        .finally(() => {
            hidePressureLoadingScreen(); // Hide loading screen after completion
        });
}

/**
 * Render pressure data into the pressure tab.
 */
function populatePressureData(data) {
    const plotContainer = document.getElementById("pressure-plot-container");
    const durationTextDiv = document.getElementById("pressure-duration-text");

    resetContainers(plotContainer, durationTextDiv);

    if (data.length === 0) {
        displayErrorMessage(plotContainer, "Error fetching pressure data. Please try again later.");
        return;
    }

    const { typeLData, typeRData } = separateDataByType(data);

    if (typeLData.length === 0 && typeRData.length === 0) {
        displayErrorMessage(plotContainer, "No pressure data available for Type L or Type R.");
        return;
    }

    addDurationText(typeLData, "L", durationTextDiv);
    addDurationText(typeRData, "R", durationTextDiv);

    renderPlots(typeLData, "Type L", plotContainer);
    renderPlots(typeRData, "Type R", plotContainer);
}

/**
 * Reset containers by clearing their content.
 */
function resetContainers(plotContainer, durationTextDiv) {
    plotContainer.innerHTML = ""; // Clear existing plots
    durationTextDiv.innerHTML = ""; // Clear existing duration text
}

/**
 * Display an error message in the plot container.
 */
function displayErrorMessage(container, message) {
    container.innerHTML = `
        <p style="text-align: center; color: red; font-size: 18px;">
            ${message}
        </p>`;
}

/**
 * Separate data into Type L and Type R.
 */
function separateDataByType(data) {
    return {
        typeLData: data.filter(row => row.Type === "L"),
        typeRData: data.filter(row => row.Type === "R"),
    };
}

/**
 * Add duration text above the plots.
 */
function addDurationText(typeData, typeName, container) {
    const durationText = calculateDurationText(typeData, typeName);
    if (durationText) {
        const line = document.createElement("div");
        line.textContent = durationText;
        container.appendChild(line);
    }
}

/**
 * Calculate duration text for Type L or Type R.
 */
function calculateDurationText(typeData, typeName) {
    const validRows = typeData.filter(row => row.MaxValue > 0);

    if (validRows.length === 0) return "";

    const firstRow = validRows[0];
    const lastRow = validRows[validRows.length - 1];
    const durationInSeconds = (new Date(`1970-01-01T${lastRow.Time}Z`) - new Date(`1970-01-01T${firstRow.Time}Z`)) / 1000;
    const parts = [];
    if (Math.floor(durationInSeconds / 3600)) parts.push(`${Math.floor(durationInSeconds / 3600)} hours`);
    if (Math.floor((durationInSeconds % 3600) / 60)) parts.push(`${Math.floor((durationInSeconds % 3600) / 60)} minutes`);
    if (durationInSeconds % 60) parts.push(`${durationInSeconds % 60} seconds`);

    const productSN = firstRow.ProductSN;
    const machine = firstRow.machine.toUpperCase();
    return `${machine} took ${parts.join(" ")} to complete ${productSN} for Type ${typeName} with ${Math.max(...typeData.map(row => row.Num))} dimms.`;
}

/**
 * Process data for grouped bar chart.
 */
function processData(filteredData) {
    const groupedData = {};
    filteredData.forEach(row => {
        if (!groupedData[row.Num]) {
            groupedData[row.Num] = [];
        }
        groupedData[row.Num].push(row);
    });

    const nums = Object.keys(groupedData).map(Number).sort((a, b) => a - b); // Sorted Num values
    const groups = nums.map(num => groupedData[num]); // Grouped rows

    const colors = ["#5DADE2", "#48C9B0", "#F5B041"]; // Custom colors for each position

    const traces = [];
    for (let i = 0; i < 3; i++) {
        traces.push({
            x: nums,
            y: nums.map(num =>
                (groups[num - 1] && groups[num - 1][i] ? groups[num - 1][i].MaxValue : 0)),
            text: nums.map(num => {
                if (groups[num - 1] && groups[num - 1][i] && groups[num - 1][i].MaxValue > 0) {
                    const time = groups[num - 1][i].Time; // Fetch the time
                    return time; // Show time at the bottom of each bar
                }
                return ""; // No text for bars with MaxValue = 0
            }),
            hoverinfo: "text", // Use text content for hover
            hovertext: nums.map(num => {
                if (groups[num - 1] && groups[num - 1][i] && groups[num - 1][i].MaxValue > 0) {
                    const pressure = groups[num - 1][i].MaxValue.toFixed(2); // Round to 2 decimal places
                    return `Pressure: ${pressure}`; // Show only Pressure in hover
                }
                return ""; // No hover text for bars with MaxValue = 0
            }),
            textposition: "outside", // Position the time text at the bottom of each bar
            name: `Position ${i + 1}`,
            type: "bar",
            marker: { color: colors[i] }, // Custom colors
        });
            
        
    }
    return traces;
}

/**
 * Render plots for the given data type and title.
 */
function renderPlots(typeData, title, container) {
    if (typeData.length === 0) return;

    const traces = processData(typeData);
    const layout = createLayout(title);

    // Calculate the maximum Y value to set a fixed axis range
    const maxY = Math.max(...traces.flatMap(trace => trace.y));

    const div = document.createElement("div");
    container.appendChild(div);

    // Initial plot with all bar heights set to 0
    const initialTraces = traces.map(trace => ({
        ...trace,
        y: trace.y.map(() => 0), // Start with all Y values as 0
    }));

    const adjustedLayout = {
        ...layout,
        yaxis: {
            ...layout.yaxis,
            range: [0, maxY * 1.1], // Set range from 0 to 10% above the max value
        },
    };

    Plotly.newPlot(div, initialTraces, adjustedLayout, { responsive: true }).then(() => {
        // Animate the bars to grow to their actual values
        const animationFrames = traces.map(trace => ({
            ...trace,
            y: trace.y, // Set to actual Y values
        }));

        Plotly.animate(
            div,
            { data: animationFrames },
            {
                transition: {
                    duration: 1000, // Animation duration in milliseconds
                    easing: "cubic-in-out", // Easing function
                },
                frame: { duration: 500, redraw: true },
            }
        );
    });
}

/**
 * Create a common layout for the plot.
 */
function createLayout(titleText) {
    return {
        autosize: true,
        title: {
            text: titleText,
            x: 0.03,
            y: 0.95,
            xanchor: "left",
            yanchor: "top",
            font: { size: 18, color: "#333" },
        },
        xaxis: { title: "Num" },
        yaxis: {
            title: { text: "MaxValue (Pressure)", standoff: 20, font: { size: 14 } },
            automargin: true,
        },
        barmode: "group",
        showlegend: true,
        legend: { orientation: "h", y: 1.1, x: 0.42 },
        margin: { t: 60, b: 40, l: 40, r: 40 },
    };
}

window.addEventListener("resize", () => {
    const plotElements = document.querySelectorAll(".plotly-graph-div");
    plotElements.forEach((plot) => {
        Plotly.Plots.resize(plot); // Dynamically resize all Plotly graphs
    });
});

export function showPressureLoadingScreen() {
    const loadingScreen = document.querySelector("#pressure-container #loading-screen");
    const pressureDurationText = document.getElementById("pressure-duration-text");
    const pressurePlotContainer = document.getElementById("pressure-plot-container");

    if (loadingScreen) {
        loadingScreen.classList.remove("hidden"); // Show the loading screen
    }
    if (pressureDurationText) {
        pressureDurationText.classList.add("hidden"); // Hide the duration text
    }
    if (pressurePlotContainer) {
        pressurePlotContainer.classList.add("hidden"); // Hide the plot container
    }
}

export function hidePressureLoadingScreen() {
    const loadingScreen = document.querySelector("#pressure-container #loading-screen");
    const pressureDurationText = document.getElementById("pressure-duration-text");
    const pressurePlotContainer = document.getElementById("pressure-plot-container");

    if (loadingScreen) {
        loadingScreen.classList.add("hidden"); // Hide the loading screen
    }
    if (pressureDurationText) {
        pressureDurationText.classList.remove("hidden"); // Show the duration text
    }
    if (pressurePlotContainer) {
        pressurePlotContainer.classList.remove("hidden"); // Show the plot container
    }
}