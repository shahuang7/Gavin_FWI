from django.contrib import admin
from .models import Line, Machine, YieldData, PressureData, ErrorData

# Register your models here.
admin.site.register(Line)
admin.site.register(Machine)
admin.site.register(YieldData)
admin.site.register(PressureData)
admin.site.register(ErrorData)