import logging
import os
from django.apps import AppConfig

logger = logging.getLogger(__name__)

class DashboardConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'dashboard'

    def ready(self):
        if os.environ.get('RUN_MAIN') == 'true':
            import threading
            import schedule
            import time
            import logging
            from django.conf import settings
            from dashboard.management.commands.update_latest_data import Command
            from dashboard.utils.db_utils import real_time_df
            from dashboard.utils.queries import (   
                get_yield_query_for_today,
                get_error_query_for_today,
                get_error_def_query,
                get_pressure_table_query_for_today,
            )

            # Initialize command and loggers
            command = Command()
            realtime_logger = logging.getLogger('realtime')
            update_logger = logging.getLogger('update')

            # Fetch database info
            db_info = settings.REMOTE_DB_INFO
            base_data_dir = settings.REAL_TIME_DATA_DIR

            # Define queries
            queries = {
                "yield": get_yield_query_for_today(),
                "error": get_error_query_for_today(),
                "error_def": get_error_def_query(),
                "pressure_table": get_pressure_table_query_for_today()[0],
            }

            # Define tasks
            def update_yield_data_task():
                try:
                    update_logger.info("Running update_yield_data...")
                    command.update_yield_data()
                    update_logger.info("update_yield_data completed.")
                except Exception as e:
                    update_logger.error(f"Error running update_yield_data: {e}")

            def update_pressure_data_task():
                try:
                    update_logger.info("Running update_pressure_data...")
                    command.update_pressure_data()
                    update_logger.info("update_pressure_data completed.")
                except Exception as e:
                    update_logger.error(f"Error running update_pressure_data: {e}")

            def update_error_data_task():
                try:
                    update_logger.info("Running update_error_data...")
                    command.update_error_data()
                    update_logger.info("update_error_data completed.")
                except Exception as e:
                    update_logger.error(f"Error running update_error_data: {e}")

            def fetch_real_time_data():
                try:
                    start_time = time.time()
                    realtime_logger.info("Starting real-time data fetching...")
                    real_time_df(db_info, queries, base_data_dir)
                    end_time = time.time()
                    elapsed_time = end_time - start_time
                    realtime_logger.info(f"Rea                                      l-time data fetching completed in {elapsed_time:.2f} seconds.")
                except Exception as e:
                    realtime_logger.error(f"Error during real-time data fetching: {e}")

            # fetch_real_time_data()    
            update_yield_data_task()
            update_pressure_data_task()
            update_error_data_task()

            # Schedule periodic tasks
            schedule.every(1).minutes.do(fetch_real_time_data)
            # schedule.every(12).hours.do(update_yield_data_task)
            # schedule.every(12).hours.do(update_pressure_data_task)
            # schedule.every(12).hours.do(update_error_data_task)

            # Start the scheduler in a separate thread
            def run_scheduler():
                while True:
                    schedule.run_pending()
                    time.sleep(1)

            threading.Thread(target=run_scheduler, daemon=True).start()




