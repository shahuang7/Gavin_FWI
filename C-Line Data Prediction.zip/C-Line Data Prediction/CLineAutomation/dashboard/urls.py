from django.urls import path
from dashboard.views import dashboard_view, fetch_dashboard_yield_data, line_detail, fetch_line_yield_data, fetch_line_pressure_data, fetch_line_error_data, check_new_error_data # Import your views

urlpatterns = [
    path('', dashboard_view, name='dashboard'),  # Route for the main dashboard
    path('fetch-dashboard-data/', fetch_dashboard_yield_data, name='fetch_dashboard_data'),
    path('line-detail/<str:line_name>/', line_detail, name='line-detail'),
    path("line/<str:line_name>/error-data/", fetch_line_error_data, name="fetch-line-error-data"),
    path("line/<str:line_name>/yield-data/", fetch_line_yield_data, name="fetch_line_yield_data"),
    path("line/<str:line_name>/pressure-data/", fetch_line_pressure_data, name="fetch_line_pressure_data"),
    path('check-new-errors/', check_new_error_data, name='check_new_errors'),
]
