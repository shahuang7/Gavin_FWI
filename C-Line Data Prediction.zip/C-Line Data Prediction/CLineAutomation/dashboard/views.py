from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
import pandas as pd
import json
import os
from datetime import datetime
from django.conf import settings

base_data_dir = settings.REAL_TIME_DATA_DIR

def dashboard_view(request):
    # Render the initial page with only the loading spinner
    return render(request, "dashboard/homepage.html")

from django.http import JsonResponse
@csrf_exempt
def fetch_dashboard_yield_data(request):
    from .utils.db_utils import historical_yield_df, generate_final_oee_dict

    try:
        # Parse filters based on HTTP method
        if request.method == "POST":
            payload = json.loads(request.body)
            selected_date = payload.get("date", str(datetime.now().date()))
            selected_machines_filter = payload.get("machines", [])
        else:  # Default GET method
            selected_date = request.GET.get("date", str(datetime.now().date()))
            selected_machines_filter = request.GET.getlist("machines[]")

        # Default filters
        selected_lines = ['C1', 'C2', 'C3', 'C4', 'C5', 'C6']
        selected_machines = ['powerfan', 'dimm1', 'dimm2', 'dimm3', 'aoi']
        if not selected_machines_filter:
            selected_machines_filter = selected_machines

        selected_date = pd.to_datetime(selected_date).date()
        today_date = datetime.now().date()
        is_today = selected_date == today_date

        # Load data
        today_yield_file = os.path.join(base_data_dir, "today_all_yield_data.csv")
        try:
            today_yield_df = pd.read_csv(today_yield_file)
            today_yield_df["Date"] = pd.to_datetime(today_yield_df["Date"]).dt.date
            today_yield_df["TimeID"] = today_yield_df["TimeID"].astype(int)
        except FileNotFoundError:
            today_yield_df = pd.DataFrame()

        if is_today:
            yield_df = today_yield_df.copy()
        else:
            yield_df = historical_yield_df(selected_date)

        final_df = yield_df[yield_df["machine"].isin(selected_machines_filter)].reset_index(drop=True)
        if final_df.empty:
            return JsonResponse({"error": "No data found for the selected filters."}, status=200)
        data = final_df.to_dict(orient="records")
        time_slots = [f"{hour:02}:00-{hour + 1:02}:00" for hour in range(24)]
        return JsonResponse({
            "data": data,  # Send all data for the day
            "lines": selected_lines,
            "machines": selected_machines,
            "current_date": str(today_date),
            "time_slots": time_slots,
            "is_today": is_today
        }, status=200)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

def line_detail(request, line_name):
    """
    Render the details page for a specific line.
    """
    context = {"line_name": line_name}
    return render(request, "dashboard/line-detail.html", context)

def fetch_line_yield_data(request, line_name):
    """
    Fetch yield data based on filter criteria and combine today's data with historical data.
    """
    from .utils.db_utils import historical_line_yield_df, calculate_filtered_oee_values

    try:
        # Paths and Parameters
        today_yield_file = os.path.join(base_data_dir, "today_all_yield_data.csv")
        selected_machine = request.GET.get("machine", "").lower()
        selected_date = request.GET.get("date", "")
        if not selected_date:
            return JsonResponse({"error": "Date parameter is missing."}, status=400)

        today_date = pd.Timestamp.now().strftime("%Y-%m-%d")
        is_today = selected_date == today_date

        # Load today's data
        try:
            today_yield_df = pd.read_csv(today_yield_file)
            today_yield_df = today_yield_df[today_yield_df["line"] == line_name]
        except FileNotFoundError:
            today_yield_df = pd.DataFrame()
        # Load historical or today's data based on the date
        if is_today:
            data_df = today_yield_df.copy()
        else:
            data_df = historical_line_yield_df(selected_date)
            data_df = data_df[data_df["line"] == line_name]
            if data_df.empty:
                return JsonResponse({"error": f"No data found for {selected_date}."}, status=404)
        # Filter data for the selected machine
        filtered_df = data_df[
            (data_df["machine"].str.lower() == selected_machine) &
            (data_df["Date"] == selected_date)
        ]
        if filtered_df.empty:
            return JsonResponse({
                "error": f"No data found for machine {selected_machine} on {selected_date}."
            }, status=404)
        # Convert data and OEE to JSON response
        response_data = {
            "filtered_data": filtered_df.to_dict(orient="records"),
            "is_today": is_today,
            "line_name": line_name,
            "selected_machine": selected_machine,
            "selected_date": selected_date,
        }
        return JsonResponse(response_data, status=200)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

def fetch_line_pressure_data(request, line_name):
    """
    Fetch pressure data based on filter criteria, either from today's data or historical data.
    """
    from .utils.db_utils import historical_line_pressure_df

    try:
        # Extract query parameters
        selected_machine = request.GET.get("machine", "").lower()
        selected_date = request.GET.get("date", "")
        today_date = pd.Timestamp.now().strftime("%Y-%m-%d")
        today_pressure_file = os.path.join(base_data_dir, "today_all_pressure_data.csv")

        # Decide data source based on the selected date
        is_today = selected_date == today_date
        if is_today:
            # Load today's data
            try:
                today_pressure_df = pd.read_csv(today_pressure_file)
                df = today_pressure_df[today_pressure_df["line"] == line_name]
            except FileNotFoundError:
                return JsonResponse({"error": "Today's pressure data file not found."}, status=404)
        else:
            # Load historical data
            df = historical_line_pressure_df(line_name, selected_machine, selected_date)
        # Filter by selected machine
        if selected_machine:
            df = df[df["machine"].str.lower() == selected_machine]

        # Group by ProductSN and Type
        product_sn_type_groups = df.groupby(["ProductSN", "Type"])

        # Identify groups where any Num appears more than three times or the sum of MaxValue is zero
        invalid_groups = product_sn_type_groups.apply(
            lambda group: group["Num"].value_counts().max() > 3 or group["MaxValue"].sum() == 0
        )

        # Get valid ProductSN-Type combinations
        valid_groups = invalid_groups[~invalid_groups].index  # Index of valid groups (tuples of ProductSN and Type)

        # Filter DataFrame to retain only valid groups
        df = df[df.set_index(["ProductSN", "Type"]).index.isin(valid_groups)]

        # Select relevant columns
        df = df[["Date", "Time", "ProductSN", "Type", "Num", "MaxValue", "line", "machine"]]
        response_data = {"filtered_data": df.to_dict(orient="records")}
        return JsonResponse(response_data, status=200)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

def fetch_line_error_data(request, line_name):
    """
    Fetch error data based on filter criteria and combine today's data with historical data.
    """
    from .utils.db_utils import historical_line_error_df, filter_and_combine_error_df, preprocess_error_df

    try:
        # Load today's data
        today_error_file = os.path.join(base_data_dir, "today_all_error_data.csv")
        today_error_df = pd.read_csv(today_error_file)
        today_error_df = preprocess_error_df(today_error_df)
        # Keep only required columns
        required_columns = [
            "StartDate", "StartTime", "EndDate", "EndTime", "Error_Def", 
            "line", "machine", "StartDateTime", "EndDateTime"
        ]
        today_error_df = today_error_df[today_error_df["line"] == line_name][required_columns]
        # Load filters
        filters = {
            "start_date": request.GET.get("start_date"),
            "end_date": request.GET.get("end_date"),
            "start_time": request.GET.get("start_time"),
            "end_time": request.GET.get("end_time"),
        }
        # Fetch historical data
        db_error_df = historical_line_error_df(line_name)
        db_error_df = db_error_df[required_columns]

        # Combine and filter data
        combined_df = filter_and_combine_error_df(today_error_df, db_error_df, filters)
        combined_df = combined_df.fillna("")  # Replace NaN for valid JSON output
        response_data = {"filtered_data": combined_df.to_dict(orient="records")}
        return JsonResponse(response_data, status=200)

    except FileNotFoundError:
        return JsonResponse({"error": "Today's error data file not found."}, status=404)
    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)

# Global dictionary to store the last known state
last_error_dict = {}

def check_new_error_data(request):
    from .utils.db_utils import preprocess_error_df
    global last_error_dict

    # Define the file path for today_all_error_data.csv
    today_error_file = os.path.join(base_data_dir, "today_all_error_data.csv")

    # Read and preprocess the error data
    if not os.path.exists(today_error_file):
        return JsonResponse({"new_errors": False, "error": "File not found"}, status=404)

    today_error_df = pd.read_csv(today_error_file)
    today_error_df = preprocess_error_df(today_error_df)

    # Create a new dictionary to track the current state
    current_error_dict = {}

    # Populate the current_error_dict with data grouped by line and machine
    for _, row in today_error_df.iterrows():
        line = row['line']
        machine = row['machine']
        error_key = f"{line}-{machine}"  # Unique key for line-machine
        error_data = {
            "StartDateTime": row["StartDateTime"],
            "EndDateTime": row["EndDateTime"],
            "Duration": row["Duration"],
            "Error_Def": row["Error_Chinese_Def"],
        }

        # Initialize the dictionary for this line-machine if it doesn't exist
        if error_key not in current_error_dict:
            current_error_dict[error_key] = []

        # Append the row's data to the list for this line-machine
        current_error_dict[error_key].append(error_data)

    # Compare current_error_dict with last_error_dict to find new rows
    new_errors = []
    for error_key, current_rows in current_error_dict.items():
        last_rows = last_error_dict.get(error_key, [])
        last_count = len(last_rows)
        current_count = len(current_rows)

        if current_count > last_count:
            # Get only the new rows
            new_rows = current_rows[last_count:]
            new_errors.extend([{"line-machine": error_key, **row} for row in new_rows])
    print(new_errors)
    # Update the global dictionary with the current state
    last_error_dict = current_error_dict

    # Return new errors to the frontend
    if new_errors:
        return JsonResponse({
            "new_errors": True,
            "new_data": new_errors
        })
    else:
        return JsonResponse({"new_errors": False})
