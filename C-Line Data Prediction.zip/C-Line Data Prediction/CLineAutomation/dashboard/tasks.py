from celery import shared_task
import logging

logger = logging.getLogger(__name__)

@shared_task
def update_latest_data():
    from dashboard.management.commands.update_latest_data import Command

    command = Command()
    try:
        logger.info("Running update tasks...")
        command.update_yield_data()
        # command.update_pressure_data()
        # command.update_error_data()
        logger.info("Update tasks completed.")
    except Exception as e:
        logger.error(f"Error running update tasks: {e}")
