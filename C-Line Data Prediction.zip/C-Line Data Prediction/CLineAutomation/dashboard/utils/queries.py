from datetime import datetime
from datetime import date

def get_yield_query_for_current_time():
    """
    Generates an SQL query to fetch real-time yield data for the current time.
    Adjusts the table name to `runtimeandyield_YYYY_MM` based on the current date.
    """
    current_time = datetime.now()
    current_date = current_time.date()
    current_hour = current_time.hour
    time_id = current_hour + 1  # Adjust as needed for your specific TimeID logic

    # Dynamically generate the table name
    table_name = f"runtimeandyiled_{current_date.year}_{current_date.month:02d}"

    # Construct the SQL query
    query = f"""
        SELECT * 
        FROM {table_name} 
        WHERE Date = '{current_date}' AND TimeID = {time_id};
    """
    return query

def get_yield_query_for_today():
    current_date = datetime.now().date()
    # Dynamically generate the table name
    table_name = f"runtimeandyiled_{current_date.year}_{current_date.month:02d}"
    # Construct the SQL query
    query = f"""
        SELECT * 
        FROM {table_name} 
        WHERE Date = '{current_date}';
    """
    return query

def get_error_query_for_today():
    today_date = date.today()
    # Query today's error data for the machine
    error_table_name = f"errorcode_{today_date.year}_{today_date.month:02d}"
    query = f"""
        SELECT * 
        FROM {error_table_name} 
        WHERE StartDate = '{today_date}';
    """
    return query

def get_error_def_query():
    query = "SELECT * FROM errorcodedef"
    return query

def get_pressure_table_query_for_today():
    today_date = date.today()
    # Query today's pressure data for the machine
    pressure_table_name = f"dimmpressure_{today_date.year}_{today_date.month:02d}"
    query = f"DESCRIBE {pressure_table_name}"
    return query, pressure_table_name

def get_pressure_query_for_today(value_cols, pressure_table):
    today_date = date.today()
    value_columns_str = ", ".join(value_cols)  # Dynamically build the column list for GREATEST
    query = f"""
        SELECT 
            DATE(Date) AS `Date`, 
            TIME_FORMAT(Time, '%H:%i:%s') AS `Time`,  -- Extracts HH:MM:SS from the Time column
            ProductSN, 
            Type, 
            Num, 
            GREATEST({value_columns_str}) AS `MaxValue`
        FROM `{pressure_table}`
        WHERE Date = '{today_date}'
    """
    return query
