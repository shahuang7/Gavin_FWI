import pandas as pd
import pymysql
import mysql.connector
from mysql.connector.errors import Error as MySQLConnectorError
from pymysql.err import MySQLError
from dashboard.models import YieldData, PressureData, ErrorData
from django.conf import settings
from datetime import datetime
import os
from contextlib import contextmanager
import numpy as np
import logging
import traceback
from dashboard.utils.queries import get_pressure_table_query_for_today, get_pressure_query_for_today

logger = logging.getLogger(__name__)
realtime_logger = logging.getLogger('realtime')
@contextmanager
def safe_connection(get_connection_func, *args, **kwargs):
    """
    Context manager to ensure database connections are safely closed.
    Returns both the connection and its type.
    """
    connection = None
    connection_type = None
    try:
        connection, connection_type = get_connection_func(*args, **kwargs)
        yield connection, connection_type
    except Exception as e:
        logger.error(f"Error with database connection: {e}\n{traceback.format_exc()}")
    finally:
        if connection:
            try:
                connection.close()
            except Exception as close_error:
                logger.error(f"Error closing database connection: {close_error}")

def get_database_connection(line, machine):
    """
    Establishes a database connection using the provided credentials for a specific line and machine.

    Parameters:
        line (str): The line name (e.g., "C2").
        machine (str): The machine name (e.g., "powerfan").

    Returns:
        tuple: (connection, connection_type) or (None, None) if connection fails.
    """
    db_info = settings.REMOTE_DB_INFO.get(line, {}).get(machine, {})
    if not db_info:
        print(f"No database info found for line '{line}' and machine '{machine}'")
        return None, None
    return connect_db(db_info["ip"], db_info["username"], db_info["password"], db_info["database"])

def connect_db(ip, username, password, database):
    """
    Tries connecting to the MySQL database using mysql-connector first, then falls back to pymysql.
    """
    try:
        connection = mysql.connector.connect(
            host=ip,
            user=username,
            password=password,
            database=database,
            connect_timeout=1
        )
        if connection.is_connected():
            print("Successfully connected using mysql-connector.")
            return connection, 'mysql-connector'
    except MySQLConnectorError as e:
        print(f"mysql-connector connection failed: {e}")

    # Fallback to pymysql
    try:
        connection = pymysql.connect(
            host=ip,
            user=username,
            password=password,
            database=database,
            connect_timeout=1
        )
        print("Successfully connected using pymysql.")
        return connection, 'pymysql'
    except MySQLError as e:
        print(f"PyMySQL connection failed: {e}")
        return None, None

def query_result(connection, connection_type, query):
    """
    Executes a query and returns the result as a DataFrame.

    Parameters:
        connection: Database connection object.
        connection_type (str): Type of the connection ('mysql-connector' or 'pymysql').
        query (str): SQL query to execute.

    Returns:
        pd.DataFrame: Query results as a pandas DataFrame.
    """
    if connection_type == 'mysql-connector':
        return query_result_mysql_connector(connection, query)
    elif connection_type == 'pymysql':
        return query_result_pymysql(connection, query)
    else:
        print("Invalid connection type.")
        return pd.DataFrame()

def query_result_mysql_connector(connection, query):
    """Executes a query using mysql-connector and returns results as a DataFrame."""
    cursor = None
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(query)
        results = cursor.fetchall()
        return pd.DataFrame(results)
    except MySQLConnectorError as e:
        print(f"Error executing query with mysql-connector: {e}")
        return pd.DataFrame()
    finally:
        if cursor:
            cursor.close()

def query_result_pymysql(connection, query):
    """Executes a query using pymysql and returns results as a DataFrame."""
    cursor = None
    try:
        cursor = connection.cursor(pymysql.cursors.DictCursor)
        cursor.execute(query)
        results = cursor.fetchall()
        return pd.DataFrame(results)
    except MySQLError as e:
        print(f"Error executing query with pymysql: {e}")
        return pd.DataFrame()
    finally:
        if cursor:
            cursor.close()

def get_matching_tables(connection, connection_type, table_prefix):
    """
    Fetches table names matching a given prefix.

    Parameters:
        connection: Database connection object.
        connection_type (str): Connection type ('mysql-connector' or 'pymysql').
        table_prefix (str): Prefix to filter tables.

    Returns:
        list: List of matching table names.
    """
    query = "SHOW TABLES"
    df = query_result(connection, connection_type, query)
    if df.empty:
        print("No tables found.")
        return []
    return [table for table in df.iloc[:, 0] if table.startswith(table_prefix)]

def query_tables_data_to_df(connection, connection_type, table_names, column_names):
    """
    Queries data from multiple tables and combines into a single DataFrame.

    Parameters:
        connection: Database connection object.
        connection_type (str): Connection type.
        table_names (list): List of table names to query.
        column_names (list): Expected DataFrame columns.

    Returns:
        pd.DataFrame: Combined data from all tables.
    """
    combined_data = []
    for table in table_names:
        query = f"SELECT * FROM `{table}`"
        df = query_result(connection, connection_type, query)
        if not df.empty:
            # Map database columns to expected column names
            db_columns = df.columns.tolist()
            column_mapping = {db_col: col for db_col, col in zip(db_columns, column_names) if db_col in db_columns}

            # Rename the columns
            df = df.rename(columns=column_mapping)
            combined_data.append(df)
    # Combine all data into a single DataFrame
    final_df = pd.concat(combined_data, ignore_index=True) if combined_data else pd.DataFrame(columns=column_names)
    return final_df

def get_machine_data(connection, connection_type, table_prefix, cols):
    """
    Fetches machine data from matching tables.

    Parameters:
        connection: Database connection object.
        connection_type (str): Connection type.
        table_prefix (str): Prefix to filter tables.
        cols (list): Columns for the resulting DataFrame.

    Returns:
        pd.DataFrame: DataFrame with machine data.
    """
    matching_tables = get_matching_tables(connection, connection_type, table_prefix)
    return query_tables_data_to_df(connection, connection_type, matching_tables, cols) if matching_tables else pd.DataFrame(columns=cols)

def query_realtime_df(db_info, tgt_machine, tgt_line, query):
    """
    Fetch real-time data from the database and return it as a DataFrame.
    """
    print(f"Fetching data for {tgt_line} : {tgt_machine}")

    try:
        # Extract database connection information
        db_details = db_info[tgt_line][tgt_machine]
        ip = db_details["ip"]
        username = db_details["username"]
        password = db_details["password"]
        database = db_details["database"]

        # Connect to the database
        connection, connection_type = connect_db(ip, username, password, database)
        if connection:
            try:
                # Execute the query and fetch the result as a DataFrame
                query_df = query_result(connection, connection_type, query)
            finally:
                # Ensure the connection is closed
                connection.close()
        else:
            query_df = pd.DataFrame()

    except KeyError as e:
        print(f"Configuration error: {e}")
        query_df = pd.DataFrame()
    except Exception as e:
        print(f"Unexpected error: {e}")
        query_df = pd.DataFrame()

    return query_df

def real_time_df(db_info, queries, base_data_dir):
    """
    Fetch and process real-time data for all lines and machines.
    """
    all_yield_dfs = []
    all_error_dfs = []
    all_pressure_dfs = []
    for line, machines in db_info.items():
        for machine in machines:
            realtime_logger.info(f"Fetching {line}-{machine} Data.")
            try:
                with safe_connection(get_database_connection, line, machine) as (connection, connection_type):
                    # Fetch data for yield
                    try:
                        yield_result = query_result(connection, connection_type, queries["yield"])
                        yield_df = realtime_yield_df(line, machine, yield_result)
                        if not yield_df.empty:
                            all_yield_dfs.append(yield_df)
                            realtime_logger.info(f"Successfully fetched yield data for {line}-{machine}.")
                    except Exception as e:
                        realtime_logger.error(f"Error fetching or processing yield data for {line}-{machine}: {e}")

                    # Fetch data for error
                    try:
                        error_result = query_result(connection, connection_type, queries["error"])
                        error_def_result = query_result(connection, connection_type, queries["error_def"])
                        error_df = realtime_error_df(line, machine, error_result, error_def_result, base_data_dir=base_data_dir)
                        if not error_df.empty:
                            all_error_dfs.append(error_df)
                            realtime_logger.info(f"Successfully fetched error data for {line}-{machine}.")
                    except Exception as e:
                        realtime_logger.error(f"Error fetching or processing error data for {line}-{machine}: {e}")

                    # Fetch data for pressure
                    try:
                        pressure_table = query_result(connection, connection_type, queries["pressure_table"])
                        if pressure_table.empty:
                            realtime_logger.warning(f"No pressure table found for {line}-{machine}.")
                            continue
                        pressure_table_cols = pressure_table["Field"].to_list()
                        pressure_value_columns = [col for col in pressure_table_cols if col.startswith("Value") and col != "ValueMax"]
                        pressure_query = get_pressure_query_for_today(pressure_value_columns, get_pressure_table_query_for_today()[1])
                        pressure_df = query_result(connection, connection_type, pressure_query)
                        pressure_df["line"] = line
                        pressure_df["machine"] = machine
                        if not pressure_df.empty:
                            all_pressure_dfs.append(pressure_df)
                            realtime_logger.info(f"Successfully fetched pressure data for {line}-{machine}.")
                    except Exception as e:
                        realtime_logger.error(f"Error fetching or processing pressure data for {line}-{machine}: {e}")

            except Exception as e:
                realtime_logger.error(f"Error processing data for {line}-{machine}: {e}")

    # Concatenate and save aggregated data
    try:
        if all_yield_dfs:
            today_all_yield_df = pd.concat(all_yield_dfs, ignore_index=True)
            today_all_yield_df.to_csv(os.path.join(base_data_dir, "today_all_yield_data.csv"), index=False)
            realtime_logger.info("Aggregated yield data saved.")

        if all_error_dfs:
            today_all_error_df = pd.concat(all_error_dfs, ignore_index=True)
            today_all_error_df.to_csv(os.path.join(base_data_dir, "today_all_error_data.csv"), index=False)
            realtime_logger.info("Aggregated error data saved.")

        if all_pressure_dfs:
            today_all_pressure_df = pd.concat(all_pressure_dfs, ignore_index=True)
            today_all_pressure_df.to_csv(os.path.join(base_data_dir, "today_all_pressure_data.csv"), index=False)
            realtime_logger.info("Aggregated pressure data saved.")
    except Exception as e:
        realtime_logger.error(f"Error saving aggregated data: {e}")

def realtime_yield_df(line, machine, result_df):
    """
    Fetch and process real-time yield data for a specific line and machine.
    """
    if result_df.empty:
        realtime_logger.warning(f"No yield data found for {line}-{machine}.")
        return pd.DataFrame()

    try:
        result_df["line"] = line
        result_df["machine"] = machine
        result_df = result_df.rename(columns={"Yiled": "Yield"})
        result_df['Date'] = pd.to_datetime(result_df['Date'])
        result_df['TimeID'] = result_df['TimeID'].astype(int)
    except Exception as e:
        realtime_logger.error(f"Error processing yield data for {line}-{machine}: {e}")
        return pd.DataFrame()

    return result_df

def realtime_error_df(line, machine, result_df, error_def_df, base_data_dir=None):
    """
    Fetch and process today's error data for a specific line and machine.
    """
    if result_df.empty:
        realtime_logger.warning(f"No error data found for {line}-{machine}.")
        return pd.DataFrame()

    try:
        if machine.startswith("dimm"):
            error_code_file = os.path.join(base_data_dir, "dimm_error_code_def.csv")
        elif machine == "powerfan":
            error_code_file = os.path.join(base_data_dir, "powerfan_error_code_def.csv")
        elif machine == "aoi":
            error_code_file = os.path.join(base_data_dir, "aoi_error_code_def.csv")
        else:
            realtime_logger.warning(f"Unknown machine type for {machine}. Skipping...")
            return pd.DataFrame()

        error_code_df = pd.read_csv(error_code_file)
        final_error_df = error_data_process(error_code_df, error_def_df, result_df)
        final_error_df["line"] = line
        final_error_df["machine"] = machine
    except Exception as e:
        realtime_logger.error(f"Error processing error data for {line}-{machine}: {e}")
        return pd.DataFrame()

    return final_error_df

def realtime_pressure_df(line, machine, result_df):
    """
    Fetch and process real-time pressure data for a specific line and machine.
    """
    if result_df.empty:
        realtime_logger.warning(f"No pressure data found for {line}-{machine}.")
        return pd.DataFrame()

    try:
        result_df['Date'] = pd.to_datetime(result_df['Date']).dt.date
        result_df['Time'] = pd.to_datetime(result_df['Time'], format='%H:%M:%S').dt.time
    except Exception as e:
        realtime_logger.error(f"Error processing pressure data for {line}-{machine}: {e}")
        return pd.DataFrame()

    return result_df

# Yield function
def is_historical(selected_date, selected_time):
    current_date = datetime.now().date()
    current_hour = int(datetime.now().hour)
    return selected_date != current_date or selected_time != current_hour

def calculate_oee_values(df, selected_machines, is_today=True):
    """
    Calculate OEE values for each line and machine.
    """
    oee_values = {}
    # Calculate OEE for each line and machine
    for line in ['C1', 'C2', 'C3', 'C4', 'C5', 'C6']:
        line_data = df[df['line'] == line]
        line_oee_values = {}

        for machine in selected_machines:
            machine_data = line_data[line_data['machine'] == machine]
            if not machine_data.empty:
                runtime = machine_data['RunTime'].iloc[0]
                standby_time = machine_data['StandByTime'].iloc[0]
                total_time = runtime + standby_time
                sum_of_times = (
                    machine_data['RunTime'].iloc[0]
                    + machine_data['StandByTime'].iloc[0]
                    + machine_data['ErrorTime'].iloc[0]
                    + machine_data['StopTime'].iloc[0]
                )

                # Historical data uses total available time
                if not is_today:
                    oee = (total_time / 3600) * 100 if 3600 > 0 else 0
                else:
                    oee = (total_time / sum_of_times) * 100 if sum_of_times > 0 else 0

                line_oee_values[machine] = float(oee)
            else:
                line_oee_values[machine] = 0
        oee_values[line] = line_oee_values

    return oee_values

def historical_yield_df(selected_date):
    """
    Fetch historical yield data from the database based on selected machines, date, and time.

    Parameters:
        selected_date (datetime.date): The date to filter data.

    Returns:
        pd.DataFrame: A DataFrame containing the historical data for all lines and selected machines.
    """
    try:

        # Filter the YieldData model based on the input parameters
        queryset = YieldData.objects.filter(
            date=selected_date
        ).select_related('line', 'machine')

        # Convert the QuerySet to a list of dictionaries
        data = list(queryset.values(
            'line__name',  # Line name
            'machine__name',  # Machine name
            'date',
            'time_id',
            'run_time',
            'standby_time',
            'error_time',
            'stop_time',
            'yield_value'
        ))

        # Convert the list of dictionaries to a DataFrame
        df = pd.DataFrame(data)

        # Rename columns to match desired output format
        df.rename(columns={
            'line__name': 'line',
            'machine__name': 'machine',
            'date': 'Date',
            'time_id': 'TimeID',
            'run_time': 'RunTime',
            'standby_time': 'StandByTime',
            'error_time': 'ErrorTime',
            'stop_time': 'StopTime',
            'yield_value': 'Yield'
        }, inplace=True)
        df['Date'] = df['Date'].astype('str')

        return df

    except Exception as e:
        print(f"Error fetching historical yield data: {e}")
        return pd.DataFrame()  # Return an empty DataFrame in case of errors

def historical_line_yield_df(selected_date):
    """
    Fetch historical yield data from the database based on selected machines, date, and time.

    Parameters:
        selected_machines (list): List of machine names (e.g., ['powerfan', 'dimm1']).
        selected_date (datetime.date): The date to filter data.
        selected_time (int): The hour to filter data.

    Returns:
        pd.DataFrame: A DataFrame containing the historical data for all lines and selected machines.
    """
    try:
        # Ensure selected_time is an integer and increment by 1 for filtering

        # Filter the YieldData model based on the input parameters
        queryset = YieldData.objects.filter(
            date=selected_date,
        ).select_related('line', 'machine')

        # Convert the QuerySet to a list of dictionaries
        data = list(queryset.values(
            'line__name',  # Line name
            'machine__name',  # Machine name
            'date',
            'time_id',
            'run_time',
            'standby_time',
            'error_time',
            'stop_time',
            'yield_value'
        ))

        # Convert the list of dictionaries to a DataFrame
        df = pd.DataFrame(data)

        # Rename columns to match desired output format
        df.rename(columns={
            'line__name': 'line',
            'machine__name': 'machine',
            'date': 'Date',
            'time_id': 'TimeID',
            'run_time': 'RunTime',
            'standby_time': 'StandByTime',
            'error_time': 'ErrorTime',
            'stop_time': 'StopTime',
            'yield_value': 'Yield'
        }, inplace=True)
        df['Date'] = df['Date'].astype('str')

        return df

    except Exception as e:
        print(f"Error fetching historical yield data: {e}")
        return pd.DataFrame()  # Return an empty DataFrame in case of errors

def calculate_filtered_oee_values(df, is_today=True):
    """
    Calculate OEE values for the current hour and whole day.

    Args:
        df (DataFrame): Filtered dataframe containing data for the specific line and machine.
        date (str): Selected date in 'YYYY-MM-DD' format.
        today_df (DataFrame): Today's data to calculate current OEE if needed.

    Returns:
        dict: A dictionary containing 'current_oee' and 'whole_day_oee'.
    """
    try:
        if df.empty:
            return {
                "current_oee": 0.0,
                "whole_day_oee": 0.0
            }
        # Initialize variables
        current_time = pd.Timestamp.now()
        current_hour = current_time.hour
        current_time_id = current_hour + 1
        if is_today:
            current_hour_data = df[df["TimeID"] == current_time_id]
            # Calculate current hour OEE
            current_run = current_hour_data["RunTime"]
            current_standby = current_hour_data["StandByTime"]
            current_error = current_hour_data["ErrorTime"]
            current_stop = current_hour_data["StopTime"]
            base_time = current_run + current_standby + current_error + current_stop

            if float(base_time.values[0]) == 0:
                current_oee = 0.0
            else:
                current_oee = float(((current_run + current_standby) / base_time * 100).values[0])
            
            elapsed_time_base = df[df["TimeID"] <= current_time_id]["RunTime"].sum() + \
                                df[df["TimeID"] <= current_time_id]["StandByTime"].sum()
            whole_day_oee = (elapsed_time_base / ((current_time_id - 1) * 3600 + current_run + current_standby)) * 100 if elapsed_time_base > 0 else 0.0
            # Ensure safe access and conversion
            if isinstance(whole_day_oee, (pd.Series, np.ndarray)):
                whole_day_oee = float(whole_day_oee.values[0])
            else:
                whole_day_oee = float(whole_day_oee)

        else:
            total_runtime = df["RunTime"].sum()
            total_standby = df["StandByTime"].sum()
            total_time_base = 3600 * 24
            current_oee = 0.0
            whole_day_oee = (total_runtime + total_standby) / total_time_base * 100 if total_time_base > 0 else 0.0
            # Ensure safe conversion
            if isinstance(whole_day_oee, (pd.Series, np.ndarray)):
                whole_day_oee = float(whole_day_oee.values[0])
            else:
                whole_day_oee = float(whole_day_oee)
        return {
            "current_oee": round(current_oee, 2),
            "whole_day_oee": round(whole_day_oee, 2)
        }

    except Exception as e:
        raise ValueError(f"Error in OEE calculation: {e}")

def generate_final_oee_dict(df, selected_lines, selected_machines, is_today=True):
    oee_dict = {}
    for line in selected_lines:
        line_yield_df = df[df["line"] == line]
        # Initialize a dictionary for each line
        oee_dict[line] = {}
        current_oee_sum = 0
        whole_day_oee_sum = 0
        machine_count = 0
        for machine in selected_machines:
            line_machine_yield_df = line_yield_df[line_yield_df["machine"] == machine]
            line_machine_yield_oee = calculate_filtered_oee_values(line_machine_yield_df, is_today)
            # Assign machine's OEE to the line's dictionary
            oee_dict[line][machine] = line_machine_yield_oee
            # Accumulate values for averaging
            current_oee = line_machine_yield_oee.get("current_oee", 0)
            whole_day_oee = line_machine_yield_oee.get("whole_day_oee", 0)
            if current_oee != 0 or whole_day_oee != 0:
                current_oee_sum += current_oee
                whole_day_oee_sum += whole_day_oee
                machine_count += 1
        
        # Avoid division by zero
        if machine_count > 0:
            oee_dict[line]["line_current_oee"] = round(current_oee_sum / machine_count,2)
            oee_dict[line]["line_whole_day_oee"] = round(whole_day_oee_sum / machine_count,2)
        else:
            oee_dict[line]["line_current_oee"] = 0.0
            oee_dict[line]["line_whole_day_oee"] = 0.0
    return oee_dict

# Pressure function
def historical_line_pressure_df(line_name, selected_machine, selected_date):
    """
    Fetch historical pressure data from the database based on selected machine, date, and line.

    Parameters:
        line_name (str): The name of the line to filter data.
        selected_machine (str): The name of the machine to filter data.
        selected_date (str): The date to filter data (in 'YYYY-MM-DD' format).

    Returns:
        pd.DataFrame: A DataFrame containing the historical data for the specified line, machine, and date.
    """
    try:
        # Query the database
        queryset = PressureData.objects.filter(
            machine__name=selected_machine,  
            date=selected_date,  
            line__name=line_name  
        ).exclude(product_sn__isnull=True).exclude(product_sn__exact="").select_related('line', 'machine')

        # Convert the QuerySet to a list of dictionaries
        data = list(queryset.values(
            'line__name',  
            'machine__name',  
            'date',  
            'time',  
            'product_sn',  
            'type',  
            'num',  
            'max_value'  
        ))

        # Convert the list of dictionaries to a DataFrame
        df = pd.DataFrame(data)

        if df.empty:
            print(f"No data found for line: {line_name}, machine: {selected_machine}, on date: {selected_date}")
            return pd.DataFrame()  # Return empty DataFrame if no data is found

        # Rename columns to match desired output format
        df.rename(columns={
            'line__name': 'line',
            'machine__name': 'machine',
            'date': 'Date',
            'time': 'Time',
            'product_sn': 'ProductSN',
            'type': 'Type',
            'num': 'Num',
            'max_value': 'MaxValue'
        }, inplace=True)

        # Ensure Date column is a string for consistency
        df['Date'] = df['Date'].astype(str)

        return df

    except Exception as e:
        print(f"Error fetching historical pressure data: {e}")
        return pd.DataFrame()  # Return an empty DataFrame in case of errors

# Error function
def preprocess_error_df(df):
    """
    Preprocess error DataFrame to add StartDateTime, EndDateTime, and Duration.

    Args:
        df (pd.DataFrame): Input DataFrame with StartDate, StartTime, EndDate, EndTime.

    Returns:
        pd.DataFrame: Preprocessed DataFrame with StartDateTime, EndDateTime, and Duration.
    """
    if not df.empty:
        df["StartDateTime"] = pd.to_datetime(
            df["StartDate"].astype(str) + " " + df["StartTime"].astype(str), errors="coerce"
        )
        df["EndDateTime"] = pd.to_datetime(
            df["EndDate"].astype(str) + " " + df["EndTime"].astype(str), errors="coerce"
        )
        df.loc[:, "Duration"] = (df["EndDateTime"] - df["StartDateTime"]).dt.total_seconds()
    return df

def historical_line_error_df(line_name):
    """
    Fetch and preprocess historical error data for the specified line.
    """
    from datetime import date
    import pandas as pd
    
    today = date.today().strftime('%Y-%m-%d')
    required_columns = [
        "line", "machine", "StartDate", "StartTime", "EndDate", "EndTime",
        "StartDateTime", "EndDateTime", "Duration", "Error_Def"
    ]

    # Query the database
    historical_errors = ErrorData.objects.filter(line__name=line_name).exclude(start_date=today).values(
        "start_date", "start_time", "end_date", "end_time", "desc_id",
        "error_code", "error_chinese_def", "error_english_def", "error_def",
        "line__name", "machine__name"
    )

    # Convert to DataFrame
    historical_df = pd.DataFrame(historical_errors)

    if not historical_df.empty:
        # Rename columns to match the required format
        historical_df.rename(
            columns={
                "line__name": "line",
                "machine__name": "machine",
                "start_date": "StartDate",
                "start_time": "StartTime",
                "end_date": "EndDate",
                "end_time": "EndTime",
                "desc_id": "DescID",
                "error_code": "Error_Code",
                "error_chinese_def": "Error_Chinese_Def",
                "error_english_def": "Error_English_Def",
                "error_def": "Error_Def"
            },
            inplace=True,
        )
        # Ensure all required columns exist in the DataFrame
        for col in required_columns:
            if col not in historical_df.columns:
                historical_df[col] = None

        # Preprocess the data
        historical_df = preprocess_error_df(historical_df)
    else:
        # Return an empty DataFrame with the required columns if no data is found
        historical_df = pd.DataFrame(columns=required_columns)

    return historical_df

def combine_error_df(today_df, historical_df):
    """
    Combine today's and historical error data after preprocessing.
    """
    today_df = preprocess_error_df(today_df)
    historical_df = preprocess_error_df(historical_df)
    return pd.concat([today_df, historical_df], ignore_index=True)

def filter_and_combine_error_df(today_df, db_df, filters):
    """
    Filter today's and historical error data based on filters, then combine the results.
    Args:
        today_df (pd.DataFrame): Today's data (already preprocessed).
        db_df (pd.DataFrame): Historical data (already preprocessed).
        filters (dict): Filters for start_date, end_date, machines, and error_defs.

    Returns:
        pd.DataFrame: Filtered and combined DataFrame.
    """
    # Ensure consistent date formats
    today_df["StartDate"] = pd.to_datetime(today_df["StartDate"], errors="coerce").dt.date
    today_df["EndDate"] = pd.to_datetime(today_df["EndDate"], errors="coerce").dt.date
    db_df["StartDate"] = pd.to_datetime(db_df["StartDate"], errors="coerce").dt.date
    db_df["EndDate"] = pd.to_datetime(db_df["EndDate"], errors="coerce").dt.date

    # Apply date range filter
    if filters.get("start_date") and filters.get("end_date"):
        start_date = pd.to_datetime(filters["start_date"]).date()
        end_date = pd.to_datetime(filters["end_date"]).date()

        today_df = today_df[(today_df["StartDate"] >= start_date) & (today_df["EndDate"] <= end_date)]
        db_df = db_df[(db_df["StartDate"] >= start_date) & (db_df["EndDate"] <= end_date)]

    # Apply machine filters
    if filters.get("machines"):
        today_df = today_df[today_df["machine"].isin(filters["machines"])]
        db_df = db_df[db_df["machine"].isin(filters["machines"])]

    # Apply error definition filters
    if filters.get("error_defs"):
        today_df = today_df[today_df["Error_Def"].isin(filters["error_defs"])]
        db_df = db_df[db_df["Error_Def"].isin(filters["error_defs"])]

    # Combine the filtered DataFrames
    combined_df = combine_error_df(today_df, db_df)

    return combined_df

def error_data_process(error_code_df, error_def_df, error_machine_df):
    """
    Processes the data:
    1. Modify 'StartTime' and 'EndTime' to HH:MM:SS in error_machine_df.
    2. Merge error_def_df.ID with error_machine_df.DescID.
    3. Merge the result on MValue with error_code_df.Error_Code.
    4. Sort the final DataFrame by StartDate, StartTime, EndDate, and EndTime.
    5. Select required columns.

    Parameters:
        error_code_df (pd.DataFrame): DataFrame containing error code definitions.
        error_def_df (pd.DataFrame): DataFrame containing error definitions.
        error_machine_df (pd.DataFrame): DataFrame containing error machine data.

    Returns:
        pd.DataFrame: The final processed DataFrame.
    """
    # Step 1: Modify 'StartTime' and 'EndTime' to HH:MM:SS
    for col in ['StartTime', 'EndTime']:
        if col in error_machine_df.columns:
            error_machine_df[col] = error_machine_df[col].astype(str).str.split(' ').str[-1]

    # Step 2: Merge error_def_df.ID with error_machine_df.DescID
    merged_df1 = pd.merge(error_def_df[['ID', 'MValue']], error_machine_df, left_on='ID', right_on='DescID', how='inner')
    # Step 3: Merge the result on MValue with error_code_df.Error_Code
    final_merged_df = pd.merge(merged_df1, error_code_df, left_on='MValue', right_on='Error_Code', how='inner')

    # Step 4: Sort by StartDate, StartTime, EndDate, and EndTime
    final_merged_df['StartDate'] = pd.to_datetime(final_merged_df['StartDate'], format='%Y-%m-%d', errors='coerce')
    final_merged_df['EndDate'] = pd.to_datetime(final_merged_df['EndDate'], format='%Y-%m-%d', errors='coerce')
    final_merged_df = final_merged_df.sort_values(by=['StartDate', 'StartTime', 'EndDate', 'EndTime'])

    # Step 5: Select required columns
    final_merged_df = final_merged_df[[
        'StartDate', 'StartTime', 'EndDate', 'EndTime',
        'DescID', 'Error_Code', 'Error_Chinese_Def', 'Error_English_Def', 'Error_Def'
    ]]

    return final_merged_df

# Helper functions for update data
# Pressure Data
def query_pressure_max_values(connection, pressure_table_names, latest_date=None):
    """
    Query maximum pressure values from the specified tables, optionally filtered by a latest date.

    Parameters:
        connection: Database connection object.
        pressure_table_names (list): List of pressure table names.
        pressure_cols (list): List of column names for the DataFrame.
        latest_date (str or None): Optional filter to query data only after this date.

    Returns:
        pd.DataFrame: DataFrame containing the combined results.
    """
    try:
        with connection.cursor() as cursor:
            combined_data = []

            for pressure_table in pressure_table_names:
                # Fetch column names dynamically
                cursor.execute(f"DESCRIBE {pressure_table}")
                columns = [row[0] for row in cursor.fetchall()]
                # Identify pressure value columns dynamically
                value_columns = [col for col in columns if col.startswith("Value") and col != "ValueMax"]
                if not value_columns:
                    print(f"No valid Value columns found in {pressure_table}. Skipping...")
                    continue

                # Dynamically construct the SQL query
                if value_columns:
                    value_columns_str = ", ".join(value_columns)  # Dynamically build the column list for GREATEST
                    query = f"""
                        SELECT 
                            DATE(Date) AS `Date`, 
                            TIME_FORMAT(Time, '%H:%i:%s') AS `Time`,  -- Extracts HH:MM:SS from the Time column
                            ProductSN, 
                            Type, 
                            Num, 
                            GREATEST({value_columns_str}) AS `MaxValue`
                        FROM `{pressure_table}`
                    """
                    if latest_date:
                        query += f" WHERE Date >= '{latest_date}'"
                    query += ";"
                    print(pressure_table)

                    # Execute the query and fetch results
                    cursor.execute(query)
                    table_data = cursor.fetchall()

                    # Create a DataFrame from the fetched data
                    df = pd.DataFrame(table_data, columns=['Date', 'Time', 'ProductSN', 'Type', 'Num', 'MaxValue'])
                    # Convert columns to appropriate types
                    df['Date'] = pd.to_datetime(df['Date']).dt.date  # Convert Date to Python date
                    df['Time'] = pd.to_datetime(df['Time'], format='%H:%M:%S').dt.time  # Convert Time to Python time

                    # Append to combined data
                    combined_data.append(df)

            # Combine data from all tables
            final_df = pd.concat(combined_data, ignore_index=True) if combined_data else pd.DataFrame()
            return final_df

    except Exception as e:
        print(f"Error querying data from tables: {e}")
        return pd.DataFrame()

