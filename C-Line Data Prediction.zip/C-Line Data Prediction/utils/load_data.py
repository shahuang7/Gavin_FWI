import pandas as pd
import json
import pymysql
import mysql.connector
from mysql.connector import Error as MySQLConnectorError
import os
from datetime import datetime

'''
Data Input / Output
'''
def read_json(json_file_path):
    # Read and load the JSON file
    try:
        with open(json_file_path, 'r') as file:
            data = json.load(file)
            print("JSON data loaded successfully:")
            return data
    except FileNotFoundError:
        print(f"File not found: {json_file_path}")
    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")

def read_df(file_path):
    return pd.read_csv(file_path)

def csv_export(df, output_path):
    """
    Export DataFrame to CSV at the specified path.

    Parameters:
        df (pd.DataFrame): The DataFrame to save.
        output_path (str): The full path where the CSV file should be saved.

    Returns:
        None
    """
    df.to_csv(output_path, index=False)
    print(f"Data has been saved to {output_path}")

'''
Database Related Functions
'''
def get_database_connection(db_info):
    """
    Reads the database info from a JSON file and establishes a connection.

    Parameters:
        json_path (str): Path to the JSON file with database connection info.

    Returns:
        connection: Database connection object.
    """
    return connect_db(db_info["ip"], db_info["user"], db_info["password"], db_info["database"])

def connect_db(ip, username, password, database):
    """Try connecting to the MySQL database using mysql-connector first, then fallback to pymysql."""
    try:
        # Try to connect using mysql-connector
        connection = mysql.connector.connect(
            host=ip,
            user=username,
            password=password,
            database=database,
            connect_timeout=5
        )
        if connection.is_connected():
            print("Successfully connected to the database using mysql-connector.")
            return connection, 'mysql-connector'
    except MySQLConnectorError as e:
        print(f"mysql-connector connection failed: {e}")
    
    # Fallback to pymysql
    try:
        connection = pymysql.connect(
            host=ip,
            user=username,
            password=password,
            database=database,
            connect_timeout=5
        )
        print("Successfully connected to the database using pymysql.")
        return connection, 'pymysql'
    except pymysql.MySQLError as e:
        print(f"PyMySQL connection failed: {e}")
        return None, None

# Query function for mysql-connector
def query_result_mysql_connector(connection, query):
    """Execute the query and return results as a DataFrame using mysql-connector-python."""
    cursor = None
    try:
        cursor = connection.cursor(dictionary=True)
        cursor.execute(query)
        results = cursor.fetchall()
        df = pd.DataFrame(results)
        return df
    except MySQLConnectorError as e:
        print(f"Error executing query using mysql-connector: {e}")
        return pd.DataFrame()
    finally:
        if cursor:
            cursor.close()

# Query function for pymysql
def query_result_pymysql(connection, query):
    """Execute the query and return results as a DataFrame using pymysql."""
    cursor = None
    try:
        cursor = connection.cursor(pymysql.cursors.DictCursor)
        cursor.execute(query)
        results = cursor.fetchall()
        df = pd.DataFrame(results)
        return df
    except pymysql.MySQLError as e:
        print(f"Error executing query using pymysql: {e}")
        return pd.DataFrame()
    finally:
        if cursor:
            cursor.close()

# Combined function to run queries
def query_result(connection, connection_type, query):
    """Execute the query using the appropriate method based on connection type."""
    if connection_type == 'mysql-connector':
        return query_result_mysql_connector(connection, query)
    elif connection_type == 'pymysql':
        return query_result_pymysql(connection, query)
    else:
        print("Invalid connection type.")
        return pd.DataFrame()

def get_matching_tables(connection, connection_type, table_prefix):
    """
    Fetch table names matching the given prefix.

    Parameters:
        connection: Database connection object.
        connection_type (str): Type of the connection (mysql-connector or pymysql).
        table_prefix (str): The prefix to filter tables.

    Returns:
        list: List of matching table names.
    """
    query = "SHOW TABLES"
    df = query_result(connection, connection_type, query)
    if df.empty:
        print("No tables found.")
        return []

    # Filter table names based on prefix
    matching_tables = [table for table in df.iloc[:, 0] if table.startswith(table_prefix)]
    return matching_tables

def query_tables_data_to_df(connection, connection_type, table_names, column_names):
    """
    Query data from the provided tables and convert to a DataFrame.

    Parameters:
        connection: Database connection object.
        connection_type (str): The type of the connection (mysql-connector or pymysql).
        table_names (list): List of table names to query data from.
        column_names (list): List of column names for the DataFrame.

    Returns:
        DataFrame: Combined data from all tables as a DataFrame.
    """
    combined_data = []

    # Loop through each table and execute the query using the query_result function
    for table in table_names:
        query = f"SELECT * FROM `{table}`"
        df = query_result(connection, connection_type, query)
        if not df.empty:
            # Map database columns to expected column names
            db_columns = df.columns.tolist()
            column_mapping = {db_col: col for db_col, col in zip(db_columns, column_names) if db_col in db_columns}

            # Rename the columns
            df = df.rename(columns=column_mapping)
            combined_data.append(df)
    # Combine all data into a single DataFrame
    final_df = pd.concat(combined_data, ignore_index=True) if combined_data else pd.DataFrame(columns=column_names)
    return final_df
    
def get_machine_data(connection, connection_type, table_prefix, cols, line, machine):
    """
    Fetches machine data from the database for the given tables and columns.

    Parameters:
        connection: Database connection object.
        connection_type (str): Type of the connection (mysql-connector or pymysql).
        table_prefix (str): Table name prefix to filter tables.
        cols (list): List of column names to extract.
        line (str): Line name to add to the DataFrame.
        machine (str): Machine name to add to the DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing machine data.
    """
    matching_tables = get_matching_tables(connection, connection_type, table_prefix)
    if matching_tables:
        df = query_tables_data_to_df(connection, connection_type, matching_tables, cols)
        return df
    return pd.DataFrame(columns=cols)

'''
Error Data Process
'''
def error_def_process(df):
    """
    Processes the error definition DataFrame.

    Parameters:
        df (pd.DataFrame): DataFrame containing raw error definition data.

    Returns:
        pd.DataFrame: DataFrame containing processed error definitions.
    """
    error_cols = ['Error_Code', "Error_Chinese_Def", "Error_English_Def"]
    df.columns = error_cols
    columns_to_clean = ["Error_Chinese_Def", "Error_English_Def"]

    # Remove string including and after the dash
    for col in columns_to_clean:
        df[col] = df[col].str.split("-").str[0]
    df['Error_Def'] = df['Error_Chinese_Def'] + "/" + df["Error_English_Def"]

    return df

def get_error_def_df(connection, connection_type, errordef_table_name):
    """
    Fetches the error definition data from the database.

    Parameters:
        connection: Database connection object.
        connection_type (str): Type of the connection (mysql-connector or pymysql).
        errordef_table_name (str): Table name containing error definitions.

    Returns:
        pd.DataFrame: DataFrame containing error definitions.
    """
    query = f"SELECT * FROM `{errordef_table_name}`"
    return query_result(connection, connection_type, query)

def error_data_process(error_code_df, error_def_df, error_machine_df):
    """
    Processes the data:
    1. Modify 'StartTime' and 'EndTime' to HH:MM:SS in error_machine_df.
    2. Merge error_def_df.ID with error_machine_df.DescID.
    3. Merge the result on MValue with error_code_df.Error_Code.
    4. Sort the final DataFrame by StartDate, StartTime, EndDate, and EndTime.
    5. Select required columns.

    Parameters:
        error_code_df (pd.DataFrame): DataFrame containing error code definitions.
        error_def_df (pd.DataFrame): DataFrame containing error definitions.
        error_machine_df (pd.DataFrame): DataFrame containing error machine data.

    Returns:
        pd.DataFrame: The final processed DataFrame.
    """
    # Step 1: Modify 'StartTime' and 'EndTime' to HH:MM:SS
    for col in ['StartTime', 'EndTime']:
        if col in error_machine_df.columns:
            error_machine_df[col] = error_machine_df[col].astype(str).str.split(' ').str[-1]

    # Step 2: Merge error_def_df.ID with error_machine_df.DescID
    merged_df1 = pd.merge(error_def_df[['ID', 'MValue']], error_machine_df, left_on='ID', right_on='DescID', how='inner')
    # Step 3: Merge the result on MValue with error_code_df.Error_Code
    final_merged_df = pd.merge(merged_df1, error_code_df, left_on='MValue', right_on='Error_Code', how='inner')

    # Step 4: Sort by StartDate, StartTime, EndDate, and EndTime
    final_merged_df['StartDate'] = pd.to_datetime(final_merged_df['StartDate'], format='%Y-%m-%d', errors='coerce')
    final_merged_df['EndDate'] = pd.to_datetime(final_merged_df['EndDate'], format='%Y-%m-%d', errors='coerce')
    final_merged_df = final_merged_df.sort_values(by=['StartDate', 'StartTime', 'EndDate', 'EndTime'])

    # Step 5: Select required columns
    final_merged_df = final_merged_df[[
        'StartDate', 'StartTime', 'EndDate', 'EndTime',
        'DescID', 'Error_Code', 'Error_Chinese_Def', 'Error_English_Def', 'Error_Def'
    ]]

    return final_merged_df

def generate_final_error_data(json_path, errordef_table_name, error_table_name, error_cols, output_file):
    """
    Connect to multiple databases, fetch data, and save to individual CSV files for each line and machine.

    Parameters:
        json_path (str): Path to the JSON file with database info.
        errordef_table_name (str): Table name for error definitions.
        error_table_name (str): Table name prefix for error machine data.
        error_cols (list): List of column names to extract.

    Returns:
        None
    """
    # Define the output directory as parallel to utils
    output_directory = os.path.join(os.path.dirname(__file__), '..', 'output')

    # Load all database configurations
    db_config = read_json(json_path)

    for line, machines in db_config.items():
        line_folder_path = os.path.join(output_directory, line)

        # Create directory for the line if it does not exist
        if not os.path.exists(line_folder_path):
            os.makedirs(line_folder_path)

        for machine, db_info in machines.items():
            machine_folder_path = os.path.join(line_folder_path, machine)

            # Create directory for the machine if it does not exist
            if not os.path.exists(machine_folder_path):
                os.makedirs(machine_folder_path)

            # Step 1: Select error code definition file based on machine type
            if machine.startswith("dimm"):
                error_code_file = "../input/dimm_error_code_def.csv"
            elif machine == "powerfan":
                error_code_file = "../input/powerfan_error_code_def.csv"
            elif machine == "aoi":
                error_code_file = "../input/aoi_error_code_def.csv"
            else:
                print(f"Unknown machine type: {machine}. Skipping...")
                continue
            # Check if the error code file exists
            if not os.path.exists(error_code_file):
                print(f"Error code file {error_code_file} does not exist for machine {machine}. Skipping...")
                continue

            # Step 2: Read error code definitions
            error_code_df = read_df(error_code_file)

            # Step 3: Establish database connection
            connection, connection_type = get_database_connection(db_info)
            if connection:
                try:
                    # Step 4: Get error machine data
                    error_machine_df = get_machine_data(connection, connection_type, error_table_name, error_cols, line, machine)
                    # Step 5: Get error definition data
                    error_def_df = get_error_def_df(connection, connection_type, errordef_table_name)

                    # Step 6: Process data
                    final_error_df = error_data_process(error_code_df, error_def_df, error_machine_df)

                    if not final_error_df.empty:
                        # Create a CSV file for the machine inside the machine folder
                        output_file_path = os.path.join(machine_folder_path, f"{output_file}.csv")
                        csv_export(final_error_df, output_file_path)
                        print(f"Error data for Line: {line}, Machine: {machine} saved to {output_file_path}")
                finally:
                    connection.close()

def update_final_error_data(json_path, errordef_table_name, error_table_name):
    """
    Update CSV files with error data for yesterday from the database, preserving historical data.

    Parameters:
        json_path (str): Path to the JSON file with database connection info.
        errordef_table_name (str): Table name for error definitions.
        error_table_name (str): Table name prefix for error machine data.
        error_cols (list): List of column names to extract.

    Returns:
        None
    """
    # Define the output directory as parallel to utils
    output_directory = os.path.join(os.path.dirname(__file__), '..', 'output')

    # Calculate yesterday's date
    today = datetime.now().date()

    # Load all database configurations
    db_config = read_json(json_path)

    for line, machines in db_config.items():
        line_folder_path = os.path.join(output_directory, line)

        for machine, db_info in machines.items():
            machine_folder_path = os.path.join(line_folder_path, machine)
            output_file_path = os.path.join(machine_folder_path, "error_data.csv")

            # If the CSV file doesn't exist, skip the update for this machine
            if not os.path.exists(output_file_path):
                print(f"No existing CSV file for Line: {line}, Machine: {machine}. Skipping...")
                continue

            # Step 1: Select error code definition file based on machine type
            if machine.startswith("dimm"):
                error_code_file = "../input/dimm_error_code_def.csv"
            elif machine == "powerfan":
                error_code_file = "../input/powerfan_error_code_def.csv"
            elif machine == "aoi":
                error_code_file = "../input/aoi_error_code_def.csv"
            else:
                print(f"Unknown machine type: {machine}. Skipping...")
                continue

            # Check if the error code file exists
            if not os.path.exists(error_code_file):
                print(f"Error code file {error_code_file} does not exist for machine {machine}. Skipping...")
                continue

            # Step 2: Read error code definitions
            error_code_df = read_df(error_code_file)

            # Step 3: Establish database connection
            connection, connection_type = get_database_connection(db_info)
            if connection:
                try:
                    # Query for today's data
                    query = f"""
                        SELECT * FROM `{error_table_name}_{today.year}_{str(today.month).zfill(2)}`
                        WHERE StartDate = '{today}';
                    """
                    today_data_df = query_result(connection, connection_type, query)

                    if not today_data_df.empty:
                        # Step 4: Get error definition data
                        error_def_df = get_error_def_df(connection, connection_type, errordef_table_name)

                        # Step 5: Process data
                        updated_error_data_df = error_data_process(error_code_df, error_def_df, today_data_df)

                        if not updated_error_data_df.empty:
                            # Load existing CSV file into a DataFrame
                            existing_df = pd.read_csv(output_file_path)

                            # Filter out rows for today's date from the existing DataFrame
                            existing_df = existing_df[existing_df['StartDate'] != str(today)]

                            # Append the new data for today's date to maintain freshness
                            updated_df = pd.concat([existing_df, updated_error_data_df], ignore_index=True)

                            # Save the updated DataFrame back to the CSV file
                            csv_export(updated_df, output_file_path)
                            print(f"Updated error data for Line: {line}, Machine: {machine} with today's data.")
                        else:
                            print(f"No new error data for today for Line: {line}, Machine: {machine}")
                    else:
                        print(f"No new data for today for Line: {line}, Machine: {machine}")
                finally:
                    connection.close()
'''
Yield Data Process
'''
def generate_final_yield_data(json_path, yield_table_name, yield_cols, output_file):
    """
    Connect to multiple databases, fetch data, and save to individual CSV files for each line and machine.

    Parameters:
        json_path (str): Path to the JSON file with database connection info.
        yield_table_name (str): Table name prefix for querying.
        yield_cols (list): List of column names to extract.
        output_file (str): The base name for the CSV file to be saved.

    Returns:
        None
    """
    # Define the output directory as parallel to utils
    output_directory = os.path.join(os.path.dirname(__file__), '..', 'output')

    # Load all database configurations
    db_config = read_json(json_path)

    for line, machines in db_config.items():
        line_folder_path = os.path.join(output_directory, line)

        # Create directory for the line if it does not exist
        if not os.path.exists(line_folder_path):
            os.makedirs(line_folder_path)

        for machine, db_info in machines.items():
            print("Querying " + line +"-" + machine)
            machine_folder_path = os.path.join(line_folder_path, machine)

            # Create directory for the machine if it does not exist
            if not os.path.exists(machine_folder_path):
                os.makedirs(machine_folder_path)

            connection, connection_type = get_database_connection(db_info)
            if connection:
                try:
                    # Fetch data from the current machine
                    machine_data = get_machine_data(connection, connection_type, yield_table_name, yield_cols, line, machine)
                    if not machine_data.empty:
                        # Create a CSV file for the machine inside the machine folder
                        output_file_path = os.path.join(machine_folder_path, f"{output_file}.csv")
                        machine_data.to_csv(output_file_path, index=False)
                        print(f"Data for Line: {line}, Machine: {machine} saved to {output_file_path}")
                finally:
                    connection.close()

def update_final_yield_data(json_path, yield_table_name):
    """
    Update CSV files with the latest data from the database, preserving historical data.

    Parameters:
        json_path (str): Path to the JSON file with database connection info.
        yield_table_name (str): Table name prefix for querying.

    Returns:
        None
    """
    # Define the output directory as parallel to utils
    output_directory = os.path.join(os.path.dirname(__file__), '..', 'output')

    # Load all database configurations
    db_config = read_json(json_path)

    for line, machines in db_config.items():
        line_folder_path = os.path.join(output_directory, line)

        for machine, db_info in machines.items():
            machine_folder_path = os.path.join(line_folder_path, machine)
            output_file_path = os.path.join(machine_folder_path, f"yield_data.csv")

            # If the CSV file doesn't exist, skip the update for this machine
            if not os.path.exists(output_file_path):
                print(f"No existing CSV file for Line: {line}, Machine: {machine}. Skipping...")
                continue

            # Load the existing CSV file to find the latest date
            existing_df = pd.read_csv(output_file_path)

            if existing_df.empty or 'Date' not in existing_df.columns:
                print(f"Invalid or empty CSV for Line: {line}, Machine: {machine}. Skipping...")
                continue

            # Find the last date in the existing CSV
            last_date = existing_df['Date'].max()

            # Connect to the database and query data after the last date
            connection, connection_type = get_database_connection(db_info)
            if connection:
                try:
                    # Query for data after the last date (inclusive for replacement)
                    query = f"""
                        SELECT * FROM `{yield_table_name}_{last_date[:4]}_{str(int(last_date[5:7])).zfill(2)}`
                        WHERE Date >= '{last_date}';
                    """
                    new_data_df = query_result(connection, connection_type, query)

                    if not new_data_df.empty:
                        # Filter out rows for the last date from the existing DataFrame
                        updated_df = existing_df[existing_df['Date'] < str(last_date)]

                        # Append the new data for the last date and beyond
                        updated_df = pd.concat([updated_df, new_data_df], ignore_index=True)

                        # Save the updated DataFrame back to the CSV file
                        csv_export(updated_df, output_file_path)
                        print(f"Updated data for Line: {line}, Machine: {machine} with new data starting from {last_date}.")
                    else:
                        print(f"No new data available for Line: {line}, Machine: {machine} after {last_date}.")
                except Exception as e:
                    print(f"Error querying data for Line: {line}, Machine: {machine}: {str(e)}")
                finally:
                    connection.close()


'''
Pressure Data Process
'''
def query_pressure_max_values(connection, pressure_table_names, pressure_cols):
    """
    Query maximum pressure values from the specified tables.

    Parameters:
        connection: Database connection object.
        pressure_table_names (list): List of pressure table names.
        pressure_cols (list): List of column names for the DataFrame.

    Returns:
        pd.DataFrame: DataFrame containing the combined results.
    """
    try:
        with connection.cursor() as cursor:
            combined_data = []
            for pressure_table in pressure_table_names:
                # Fetch column names
                cursor.execute(f"DESCRIBE {pressure_table}")
                columns = [row[0] for row in cursor.fetchall()]

                # Identify the Value columns dynamically
                value_columns = [col for col in columns if col.startswith("Value") and col != "ValueMax"]

                # Construct the SQL query
                value_columns_str = ", ".join(value_columns)
                query = f"""
                    SELECT Date, Time, ProductSN, Type, Num,
                           GREATEST({value_columns_str}) AS MAX_VALUE 
                    FROM {pressure_table};
                """
                
                # Execute the query and fetch results
                cursor.execute(query)
                table_data = cursor.fetchall()
                combined_data.extend(table_data)

            # Convert combined data to DataFrame
            df = pd.DataFrame(combined_data, columns=pressure_cols)
            return df
    except Exception as e:
        print(f"Error querying data from tables: {e}")
        return pd.DataFrame()

def generate_final_pressure_data(json_path, pressure_table_name, pressure_cols, output_file):
    """
    Connect to multiple databases, fetch pressure data, and save to CSV files.

    Parameters:
        json_path (str): Path to the JSON file with database connection info.
        pressure_table_name (str): Table name prefix for querying.
        pressure_cols (list): List of column names to extract.
        output_file (str): The base name for the CSV file to be saved.

    Returns:
        pd.DataFrame: Combined DataFrame with pressure data.
    """
    # Define the output directory as parallel to utils
    output_directory = os.path.join(os.path.dirname(__file__), '..', 'output')

    # Load all database configurations
    db_config = read_json(json_path)

    for line, machines in db_config.items():
        line_folder_path = os.path.join(output_directory, line)

        # Create directory for the line if it does not exist
        if not os.path.exists(line_folder_path):
            os.makedirs(line_folder_path)

        for machine, db_info in machines.items():
            print("Querying " + line +"-" + machine)
            machine_folder_path = os.path.join(line_folder_path, machine)

            # Create directory for the machine if it does not exist
            if not os.path.exists(machine_folder_path):
                os.makedirs(machine_folder_path)

            connection, connection_type = get_database_connection(db_info)
            if connection:
                try:
                    # Fetch pressure data from the current machine
                    pressure_machine_match_tables = get_matching_tables(connection, connection_type, pressure_table_name)
                    pressure_machine_df = query_pressure_max_values(connection, pressure_machine_match_tables, pressure_cols)
                    
                    if not pressure_machine_df.empty:
                        # Clean up the 'Time' column
                        pressure_machine_df['Time'] = pressure_machine_df['Time'].astype(str).str.split(' ').str[-1]

                        # Create a CSV file for the machine inside the machine folder
                        output_file_path = os.path.join(machine_folder_path, f"{output_file}.csv")
                        csv_export(pressure_machine_df, output_file_path)
                finally:
                    connection.close()

def update_final_pressure_data(json_path, pressure_table_name, pressure_cols):

    
    """
    Update CSV files with pressure data for the current month from the database, preserving historical data.

    Parameters:
        json_path (str): Path to the JSON file with database connection info.
        pressure_table_name (str): Table name prefix for querying.
        pressure_cols (list): List of column names to extract.

    Returns:
        None
    """
    # Define the output directory as parallel to utils
    output_directory = os.path.join(os.path.dirname(__file__), '..', 'output')

    # Calculate current year and month
    current_year = datetime.now().year
    current_month = str(datetime.now().month).zfill(2)
    current_date = datetime.now().date()

    # Construct the table name for the current month
    current_pressure_table = f"{pressure_table_name}_{current_year}_{current_month}"

    # Load all database configurations
    db_config = read_json(json_path)

    for line, machines in db_config.items():
        line_folder_path = os.path.join(output_directory, line)

        for machine, db_info in machines.items():
            machine_folder_path = os.path.join(line_folder_path, machine)
            output_file_path = os.path.join(machine_folder_path, f"pressure_data.csv")

            # If the CSV file doesn't exist, skip the update for this machine
            if not os.path.exists(output_file_path):
                print(f"No existing CSV file for Line: {line}, Machine: {machine}. Skipping...")
                continue

            # Connect to the database and query data for the current month table
            connection, connection_type = get_database_connection(db_info)
            if connection:
                try:
                    # Check if the current month's pressure table exists
                    query = f"SHOW TABLES LIKE '{current_pressure_table}'"
                    table_exists_df = query_result(connection, connection_type, query)
                    if not table_exists_df.empty:
                        # Use the existing query_pressure_max_values function to get data
                        pressure_machine_match_tables = [current_pressure_table]  # Single table for the current month
                        pressure_data_df = query_pressure_max_values(connection, pressure_machine_match_tables, pressure_cols)

                        if not pressure_data_df.empty:
                            # Filter for today's data only
                            pressure_data_df = pressure_data_df[pressure_data_df['Date'] == current_date]
                            # Load existing CSV file into a DataFrame
                            existing_df = pd.read_csv(output_file_path)

                            # Filter out rows for today's date from the existing DataFrame
                            updated_df = existing_df[existing_df['Date'] != current_date]
                            # Append the new data for today to maintain freshness
                            updated_df = pd.concat([updated_df, pressure_data_df], ignore_index=True)
                            
                            # Clean up the 'Time' column
                            updated_df['Time'] = updated_df['Time'].astype(str).str.split(' ').str[-1]

                            # Save the updated DataFrame back to the CSV file
                            csv_export(updated_df, output_file_path)
                            print(f"Updated pressure data for Line: {line}, Machine: {machine} with today's data.")
                        else:
                            print(f"No new pressure data for today for Line: {line}, Machine: {machine}")
                    else:
                        print(f"Table {current_pressure_table} does not exist for Line: {line}, Machine: {machine}.")
                finally:
                    connection.close()


