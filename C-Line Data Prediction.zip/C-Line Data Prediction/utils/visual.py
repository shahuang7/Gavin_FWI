import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
import plotly.graph_objects as go

def df_intro(df):
    # Print basic information about the DataFrame
    print("DataFrame Info:\n")
    print("-" * 40)
    print(df.info())

    # Print a statistical summary of the DataFrame
    print("\nDescriptive Statistics:\n")
    print("-" * 40)
    print(df.describe())

    # Check for missing data
    print("\nMissing Data Summary:\n")
    print("-" * 40)
    print(df.isnull().sum())

    # Preview the first few rows
    print("\nPreview of the DataFrame (First 5 Rows):\n")
    print("-" * 40)
    print(df.head())


def plot_heatmap(df, date_col, timeid_col, value_col):
    """
    Plot a heatmap for hourly trends.
    Args:
        df (pd.DataFrame): The DataFrame to plot.
        date_col (str): The column name representing dates.
        timeid_col (str): The column name representing TimeID (hour).
        value_col (str): The column name representing the value to plot.
    """
    heatmap_data = df.pivot_table(index=date_col, columns=timeid_col, values=value_col, aggfunc='mean')
    plt.figure(figsize=(15, 10))
    sns.heatmap(heatmap_data, cmap='coolwarm', cbar_kws={'label': value_col})
    plt.title(f'Hourly Heatmap for {value_col}')
    plt.xlabel('Hour (TimeID)')
    plt.ylabel('Date')
    plt.show()

def plot_stacked_bar_with_percentage_and_yield(df, date_col, time_cols, yield_col):
    """
    Create a stacked bar chart with percentages and overlay Yield as a line chart.
    
    Args:
        df (pd.DataFrame): The DataFrame to plot.
        date_col (str): The column representing dates.
        time_cols (list): List of columns representing time types.
        yield_col (str): The column representing Yield.
    """
    # Format date column for hover consistency
    df['FormattedDate'] = df[date_col].dt.strftime('%Y-%m-%d')

    # Initialize the figure
    fig = go.Figure()

    # Adjust hover text for bar traces to remove unnecessary date formatting
    for col in time_cols:
        fig.add_trace(go.Bar(
            x=df[date_col],  # Use dates with data
            y=df[f'{col}_Pct'],  # Use percentage for stacking
            name=col,
            marker_color={'RunTime': 'green', 'StandByTime': 'blue', 'ErrorTime': 'yellow', 'StopTime': 'red'}[col],
            hoverinfo='text',  # Use manual hover text
            text=df.apply(
                lambda row: f"{col}: {row[col]:.2f} seconds<br>"
                            f"Percentage: {row[f'{col}_Pct']:.2f}%",
                axis=1
            ),  # Generate hover text dynamically
        ))

    # Add line trace for Yield (secondary y-axis)
    fig.add_trace(go.Scatter(
        x=df[date_col],  # Use dates with data
        y=df[yield_col],
        mode='lines+markers',
        name='Yield',
        line=dict(width=2, color='black'),  # Customize line appearance
        marker=dict(size=5),
        yaxis='y2',  # Assign to secondary y-axis
        hovertemplate='Date: %{x|%Y-%m-%d}<br>Yield: %{y:.0f}<extra></extra>',  # Format hover text
    ))

    # Update layout for dual y-axes and better visualization
    fig.update_layout(
        title='Time Distribution (Percentage) and Yield Sum',
        xaxis=dict(
            title='Date',
            type='category',  # Use category-based axis
            categoryorder='category ascending',  # Order categories chronologically
            tickvals=df[date_col][::10],  # Approximate x-ticks to prevent overlap
            ticktext=df[date_col][::10].dt.strftime('%Y/%m'),  # Format x-ticks as YYYY/MM
        ),
        yaxis=dict(
            title='Time Distribution (%)',
            range=[0, 100],  # 100% scale for stacked bar
            showgrid=True,
        ),
        yaxis2=dict(
            title='Yield (Sum)',
            overlaying='y',
            side='right',
            showgrid=False,
            range=[0, max(df[yield_col])],  # Ensure Yield starts at 0
        ),
        barmode='stack',  # Ensure bars are stacked
        bargap=0,  # Remove gaps between bars
        legend=dict(
            orientation="h",  # Horizontal legend
            yanchor="bottom",
            y=1.05,
            xanchor="center",
            x=0.5,
        ),
        template='plotly',
        hovermode='x unified',  # Unified hover text
        height=600,
        width=1700,  # Adjust plot width
    )

    # Show the figure
    fig.show()

def plot_rolling_average(df, date_col, value_col, window=30):
    """
    Plot rolling average trends to smooth the data.
    Args:
        df (pd.DataFrame): The DataFrame to plot.
        date_col (str): The column name representing dates.
        value_col (str): The column name to smooth and plot.
        window (int): The rolling window size.
    """
    df['RollingAvg'] = df[value_col].rolling(window=window).mean()
    plt.figure(figsize=(15, 6))
    plt.plot(df[date_col], df['RollingAvg'], label=f'{value_col} ({window}-Day Rolling Avg)')
    plt.title(f'Rolling Average for {value_col}')
    plt.xlabel('Date')
    plt.ylabel(value_col)
    plt.legend()
    plt.grid()
    plt.show()

def plot_comparison_with_difference(comparison_df, date_col='Date'):
    """
    Plot Actual vs Predicted Yield with difference on a secondary y-axis.
    
    Args:
        comparison_df (pd.DataFrame): DataFrame containing Date, Actual Yield, and Predicted Yield.
        date_col (str): Name of the Date column in the comparison DataFrame.
    """
    # Calculate the difference
    comparison_df['Difference'] = comparison_df['Actual Yield'] - comparison_df['Predicted Yield']
    
    # Create the figure and axis
    fig, ax1 = plt.subplots(figsize=(14, 8))
    
    # Plot Actual and Predicted Yield on the primary y-axis
    ax1.plot(comparison_df[date_col], comparison_df['Actual Yield'], label='Actual Yield', marker='o', color='blue')
    ax1.plot(comparison_df[date_col], comparison_df['Predicted Yield'], label='Predicted Yield', marker='x', color='orange')
    ax1.set_xlabel('Date')
    ax1.set_ylabel('Yield', color='black')
    ax1.tick_params(axis='y', labelcolor='black')
    ax1.set_title('Actual vs Predicted Yield with Difference', fontsize=16)
    
    # Add legend for the primary y-axis
    ax1.legend(loc='upper left')
    
    # Create a secondary y-axis for the difference
    ax2 = ax1.twinx()
    ax2.plot(comparison_df[date_col], comparison_df['Difference'], label='Difference', color='red', linestyle='--')
    ax2.set_ylabel('Difference (Actual - Predicted)', color='red')
    ax2.tick_params(axis='y', labelcolor='red')
    ax2.axhline(0, color='gray', linestyle='--', linewidth=0.8)  # Center horizontal line at 0 on the second axis
    
    # Adjust secondary axis to center the 0 line
    max_diff = abs(comparison_df['Difference']).max()
    ax2.set_ylim(-max_diff, max_diff)
    
    # Add legend for the secondary y-axis
    ax2.legend(loc='upper right')
    
    # Improve x-axis ticks for readability
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    # Show the plot
    plt.show()