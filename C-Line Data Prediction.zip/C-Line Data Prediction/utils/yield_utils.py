import pandas as pd
from sklearn.model_selection import train_test_split
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV

def prepare_yield_data(df, metrics, freq='D', lags=3):
    """
    Prepare data for future yield prediction by creating lagged and temporal features.
    
    Args:
        df (pd.DataFrame): Input data containing Date and metrics.
        metrics (list): List of metric columns to use.
        freq (str): Resampling frequency ('D' for daily, 'H' for hourly).
        lags (int): Number of lagged intervals to include.
        
    Returns:
        pd.DataFrame: Data with lagged features and temporal features.
    """
    df_copy = df.copy()
    # Ensure the date column is in datetime format
    df_copy['Date'] = pd.to_datetime(df_copy['Date'])

    if freq == 'D':
        # Start with daily data
        aggregated_data = df_copy[['Date'] + metrics].copy()
    else:
        raise ValueError("Frequency must be 'D' (daily).")
    
    # Add lagged features
    for lag in range(1, lags + 1):
        for col in metrics:
            aggregated_data[f'{col}_t-{lag}'] = aggregated_data[col].shift(lag)
    
    # Add temporal features
    aggregated_data['DayOfWeek'] = aggregated_data['Date'].dt.dayofweek
    aggregated_data['Weekend'] = (aggregated_data['DayOfWeek'] >= 5).astype(int)
    aggregated_data['Month'] = aggregated_data['Date'].dt.month
    
    # Remove rows with NaN values caused by lagging
    aggregated_data.dropna(inplace=True)
    
    # Select required columns for training
    lagged_cols = [f'{col}_t-{lag}' for lag in range(1, lags + 1) for col in metrics]
    temporal_cols = ['DayOfWeek', 'Weekend', 'Month']
    required_cols = ['Date', 'Yield'] + lagged_cols + temporal_cols
    
    return aggregated_data[required_cols].reset_index(drop=True)

def create_yield_features(data, freq='D'):
    """
    Create features for modeling.
    Args:
        data (pd.DataFrame): Input data (daily or hourly).
        freq (str): Frequency ('D' for daily, 'H' for hourly).
    Returns:
        pd.DataFrame: Data with additional features.
    """
    data = data.copy()
    
    # Add lagged features
    for lag in range(1, 4):  # Lag for the past 3 intervals
        for col in ['RunTime', 'StandByTime', 'ErrorTime', 'StopTime', 'Yield']:
            data[f'{col}_t-{lag}'] = data[col].shift(lag)
    
    # Add time-based features
    if freq == 'D':
        data['DayOfWeek'] = data['Date'].dt.dayofweek
        data['Weekend'] = (data['DayOfWeek'] >= 5).astype(int)
    elif freq == 'H':
        data['Hour'] = data['Date'].dt.hour
    
    # Add rolling averages (for hourly data)
    if freq == 'H':
        for col in ['RunTime', 'StandByTime', 'ErrorTime', 'StopTime', 'Yield']:
            data[f'{col}_rolling_mean'] = data[col].rolling(window=3).mean()
    
    # Drop rows with NaN values from lagged features
    data.dropna(inplace=True)
    
    return data

def scale_features(X_train, X_val, X_test):
    """
    Scale features using StandardScaler.
    
    Args:
        X_train (pd.DataFrame): Training feature set.
        X_val (pd.DataFrame): Validation feature set.
        X_test (pd.DataFrame): Test feature set.
        
    Returns:
        X_train_scaled, X_val_scaled, X_test_scaled: Scaled feature sets.
    """
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)
    return X_train_scaled, X_val_scaled, X_test_scaled

def split_yield_data(data, target, test_size=0.2, validation_size=0.2):
    """
    Split data into training, validation, and testing sets while preserving time-series order.
    Args:
        data (pd.DataFrame): Input data with features.
        target (str): Target column name.
        test_size (float): Proportion of the test set.
        validation_size (float): Proportion of the training set for validation.
    Returns:
        X_train, X_val, X_test, y_train, y_val, y_test
    """
    # Drop Date column and extract features and target
    X = data.drop(columns=[target, 'Date'])
    y = data[target]
    
    # Define indices for splitting
    test_split_idx = int(len(data) * (1 - test_size))
    val_split_idx = int(test_split_idx * (1 - validation_size))
    
    # Train, validation, test split
    X_train, X_val, X_test = X.iloc[:val_split_idx], X.iloc[val_split_idx:test_split_idx], X.iloc[test_split_idx:]
    y_train, y_val, y_test = y.iloc[:val_split_idx], y.iloc[val_split_idx:test_split_idx], y.iloc[test_split_idx:]
    
    return X_train, X_val, X_test, y_train, y_val, y_test

def evaluate_model(y_true, y_pred):
    """
    Evaluate the model using MAE, MSE, RMSE, and R².
    
    Args:
        y_true (array-like): Actual target values.
        y_pred (array-like): Predicted target values.
        
    Returns:
        dict: Dictionary containing evaluation metrics.
    """
    mae = mean_absolute_error(y_true, y_pred)
    mse = mean_squared_error(y_true, y_pred)
    rmse = np.sqrt(mse)
    r2 = r2_score(y_true, y_pred)
    
    print(f"MAE: {mae:.2f}")
    print(f"MSE: {mse:.2f}")
    print(f"RMSE: {rmse:.2f}")
    print(f"R²: {r2:.2f}")
    
    return {"MAE": mae, "MSE": mse, "RMSE": rmse, "R²": r2}

def train_yield_model(X_train, y_train, X_val, y_val):
    """
    Train an XGBoost model with validation data and evaluate performance.
    Args:
        X_train (pd.DataFrame): Training features.
        y_train (pd.Series): Training target.
        X_val (pd.DataFrame): Validation features.
        y_val (pd.Series): Validation target.
    Returns:
        model: Trained XGBoost model.
    """
    # Initialize the model
    model = XGBRegressor(
        objective='reg:squarederror',
        n_estimators=500,
        learning_rate=0.05,
        max_depth=6,
        random_state=42,
        early_stopping_rounds=10  # Use early_stopping instead of early_stopping_rounds
    )
    
    # Train the model with validation set
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],  # Provide validation data for evaluation
        verbose=False
    )
    
    # Evaluate on validation data
    y_val_pred = model.predict(X_val)
    mae = mean_absolute_error(y_val, y_val_pred)
    mse = mean_squared_error(y_val, y_val_pred)
    print(f"Validation MAE: {mae:.2f}")
    print(f"Validation MSE: {mse:.2f}")
    
    return model

def tune_hyperparameters(X_train, y_train, X_val, y_val):
    """
    Perform hyperparameter tuning using GridSearchCV.
    
    Args:
        X_train (pd.DataFrame): Training features.
        y_train (pd.Series): Training target.
        X_val (pd.DataFrame): Validation features.
        y_val (pd.Series): Validation target.
        
    Returns:
        best_model: Best XGBoost model after tuning.
        best_params: Best hyperparameters found by GridSearchCV.
    """
    param_grid = {
        "n_estimators": [100, 200, 300],
        "learning_rate": [0.01, 0.05, 0.1],
        "max_depth": [3, 5, 7],
        "subsample": [0.7, 0.9, 1.0],
        "colsample_bytree": [0.7, 0.9, 1.0]
    }
    
    # Initialize the model
    xgb = XGBRegressor(objective='reg:squarederror', random_state=42)
    
    # Initialize GridSearchCV
    grid_search = GridSearchCV(
        estimator=xgb,
        param_grid=param_grid,
        scoring="neg_mean_squared_error",
        cv=3,
        verbose=1
    )
    
    # Fit GridSearchCV
    grid_search.fit(X_train, y_train)
    
    # Get the best model
    best_model = grid_search.best_estimator_
    best_params = grid_search.best_params_
    
    print(f"Best Parameters: {best_params}")
    return best_model, best_params

def compare_actual_vs_predicted(model, X_test, y_test, data, date_col='Date'):
    """
    Create a DataFrame comparing actual and predicted yield values.
    
    Args:
        model: Trained XGBoost model.
        X_test (pd.DataFrame): Test features.
        y_test (pd.Series): Actual yield values from the test set.
        data (pd.DataFrame): Original data containing the Date column.
        date_col (str): Name of the Date column in the original data.
    
    Returns:
        pd.DataFrame: A DataFrame with Date, Predicted Yield, and Actual Yield.
    """
    # Predict yield using the test set
    y_pred = model.predict(X_test)
    
    # Create a comparison DataFrame
    comparison_df = pd.DataFrame({
        date_col: data.loc[y_test.index, date_col],  # Align dates from the original data
        'Actual Yield': y_test.values,
        'Predicted Yield': y_pred
    })
    
    # Sort by Date (optional)
    comparison_df = comparison_df.sort_values(by=date_col).reset_index(drop=True)
    
    return comparison_df


